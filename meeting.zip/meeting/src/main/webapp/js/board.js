
$(function(){
	
	init();
	var meetId = $('#meetId').val();
	$('#messageList').datagrid({
		queryParams: {
			meetId: meetId,
		}
	});
	
	$("#message").keyup(function(){
		var text=$("#message").val();
	    if(text.length <= 200)
	    {
	        $("#plug").html(text.length);
	    }else{
	    	$.messager.alert('提示','最大输入数为200','info');
	    }
	});
	
	$("#message").blur(function(){
		var text=$("#message").val();
		if(text.length == 0)
		{
			$(".text").html("留言:");
			$("#type").val("1");
			$("#replyMsgId").val(0);
			$("#replyUserId").val(0);
			$("#messageList").datagrid('unselectAll');
		}
	});
	
	$("#sendMsg").click(function(){
		var message = $("#message").val();
		if(message.length == 0)
			return;
		$("#content").val(message);
		$.ajax({
            url:"../message/sendMsg",
            data:$("#sendForm").serialize(),
            success:function(data){
                if(data.status == 200){
                	$("#message").val("");
                	$("#message").keyup();
                	$(".text").html("留言:");
        			$("#type").val("1");
        			$("#replyMsgId").val(0);
        			$("#replyUserId").val(0);
                	var meetId = $('#meetId').val();
                	$('#messageList').datagrid({
                		queryParams: {
                			meetId: meetId,
                		}
                	});
                }else{
                	$.messager.alert('提示',data.description,'info');
                }
            }
		});
	});
	
	$('#messageList').datagrid({
		onClickCell: function(rowIndex,field,value){
			if(field == "handle"){
				$("#messageList").datagrid('selectRow',rowIndex);
				var select = $("#messageList").datagrid("getSelected");
				$(".text").html("回复:");
				$("#type").val("2");
				$("#replyMsgId").val(select.pkid);
				$("#replyUserId").val(select.userId);
				$("#message").focus();
			}else{
				return;
			}
		}
	});
})
function init(){
	$('#messageList').datagrid({
		//title: '会议列表',
		url: '../message/findMsgByMeetId',
		method: 'post',
		striped: true,
		autoRowHeight:false,
		singleSelect:true,
		showHeader:false,
		nowrap:false,
		columns : [ [ { 
		 	field : 'pkid', 
		 	width : '10%', 
		 	title:'ID',
		 	hidden:true
            },
            { 
           	 	field : 'userName', //名字
           	 	width : '7%', 
           	 	align : 'center',
           	 	styler: function(value,row,index){
					return 'border:0px';
				},
			 },
			 { 
				 field : 'strCreatTime', //时间
				 width : '15%', 
				 align : 'center',
				 styler: function(value,row,index){
						return 'border:0px';
					},
			 },
			 { 
				 field : 'typeName',   //类型
				 width : '7%', 
				 align : 'center', 
				 styler: function(value,row,index){
						return 'border:0px';
					},
			 },
			 { 
				 field : 'replyUserName', //名字
				 width : '7%', 
				 align : 'center', 
				 styler: function(value,row,index){
						return 'border:0px';
					},
			 },
			 { 
				 field : 'content',     //内容
				 width : '56%', 
				 align : 'left', 
				 styler: function(value,row,index){
							return 'border:0px';
						},
			 	},
			 { 
				 field : 'handle',     //操作
				 width : '9%', 
				 align : 'left', 
				 styler: function(value,row,index){
						return 'border:0px;color:blue';
					},
			 }
			] ],
		idField:'pkid', 
		loadMsg:'请稍候，数据加载中...', 
		//emptyMsg:'查询数据为空...',
	});
}
function formatter(value,row,index) {
    return '<div style="width=250px;word-break:break-all;word-wrap:break-word;white-space:pre-wrap;">'+value+'</div>';
}