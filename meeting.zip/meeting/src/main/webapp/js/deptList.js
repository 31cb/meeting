
$(function(){
	
	init();
	
	$("#search_btn").click(function(){
		var deptNum = $('#deptNum').val();
		var deptName = $('#deptName').val();
		$('#deptList').datagrid({
			queryParams: {
				deptNum: deptNum,
				deptName: deptName,
			}
		});
		var p = $('#deptList').datagrid('getPager');  
		$(p).pagination({  
		    beforePageText: '第',//页数文本框前显示的汉字   
		    afterPageText: '页    共 {pages} 页',  
		    displayMsg: '第{from}到{to}条，共{total}条',  
		});
	});
	
	$("#add_btn").click(function(){
		$("#editForm").form("clear");
		$("#editForm").form("reset");
		$("#dialog").dialog().find("font").remove();
		$("#dialog").dialog("open");
	});

	$("#update_btn").click(function(){
		var select = $("#deptList").datagrid("getSelected");
		if(select == null){
			$.messager.alert('提示','请选择一条记录','error');
			return
		}
		$("#dialog").dialog().find("font").remove();
		$("#dialog").dialog("open");
		$("#editForm").form("load",select);
		$("#edit_deptNum").unbind();
		$("#edit_deptName").unbind();
	});
	
	$("#del_btn").click(function(){
		var select = $("#deptList").datagrid("getSelected");
		if(select == null){
			$.messager.alert('提示','请选择一条记录','error');
			return
		}
		var pkid = select.pkid;
		$.messager.confirm("删除会议室","是否确认删除该会议室!",function(r){
			if(r){
				$.ajax({
		            url:"../dept/deleteDept",
		            data:"pkid="+pkid,
		            success:function(data){
		                if(data.status == 200){
		                	$.messager.alert('提示',data.description,'info');
		                	$('#deptList').datagrid('reload');
		                }else{
		                	$.messager.alert('提示',data.description,'info');
		                }
		            }
				});
			}
		});
	});
	
	$("#cancel_btn").click(function(){
		$("#dialog").dialog("close");
	});
	
	$("#editForm").validate({
		rules : {
			deptNum : {
				required : true,
				maxlength : 32,
			},
			deptName : {
				required : true,
				maxlength : 32,
			},
		},
		messages : {
			deptNum : {				
				required : "<font color=red> *部门编号不为空</font>",
				maxlength : "<font color=red> *部门编号最大长度32</font>",
			},
			deptName : {				
				required : "<font color=red> *部门名称不为空</font>",		
				rangelength : "<font color=red> *部门名称最大长度32</font>",
			},
		}
	});
	
	$("#save_btn").click(function(){
		if($("#editForm").valid()){
			$('#editForm').form('submit', {
			    url:"../dept/addOrUpdate",
			    success: function(data){
			    	data = eval( '('+data+')' );
			    	if(data.status==200){
			    		$.messager.alert('提示',data.description,'info');
			    		$("#dialog").dialog("close");
			    		$('#deptList').datagrid('reload');
			    	}else{
			    		$.messager.alert('提示',data.description,'info');
			    		$("#dialog").dialog("close");
			    	}
			    }
			});
		}
	});
	
	$("#edit_deptNum").blur(function(){
		var deptNum = $("#edit_deptNum").val();
		$.ajax({
            url:"../dept/existDeptNum",
            data:"deptNum="+deptNum,
            success:function(data){
                if(data.status == 100){
                	$.messager.alert('提示',data.description,'info',function(){
                		$("#edit_deptNum").focus();
                    	$("#edit_deptNum").val('');
                	});
                }else{
                	
                }
            }
		});
	});
	$("#edit_deptName").blur(function(){
		var deptName = $("#edit_deptName").val();
		$.ajax({
			url:"../dept/existDeptName",
			data:"deptName="+deptName,
			success:function(data){
				if(data.status == 100){
					$.messager.alert('提示',data.description,'info',function(){
						$("#edit_deptName").focus();
						$("#edit_deptName").val('');
					});
				}else{
					
				}
			}
		});
	});
	
	
})

function init(){
	
	$('#deptList').datagrid({
		title: '部门列表',
		url: '../dept/findDeptList',
		method: 'post',
		striped: true,
		autoRowHeight:false,
		singleSelect:true,
		nowrap:false,
		columns : [ [ { 
		 	field : 'pkid', 
		 	width : '10%', 
		 	title:'ID',
		 	checkbox:true 
            },
            { 
           	 	field : 'deptNum', 
           	 	title : '部门编号', 
           	 	width : '25%', 
           	 	align : 'center' 
			 },
			 { 
				 field : 'deptName', 
				 title : '部门名称', 
				 width : '25%', 
				 align : 'center', 
			 },
			{ 
				field : 'remark', 
				title : '备注', 
				width : '49%',
				align : 'center', 
			}
			] ],
		idField:'pkid', 
		loadMsg:'请稍候，数据加载中...', 
		emptyMsg:'查询数据为空...',
		pagination:true,
		pageSize:5,   //表格中每页显示的行数
		pageList:[5,10,15]
	});
	
	var p = $('#deptList').datagrid('getPager');  
	$(p).pagination({  
	    beforePageText: '第',//页数文本框前显示的汉字   
	    afterPageText: '页    共 {pages} 页',  
	    displayMsg: '第{from}到{to}条，共{total}条',  
	}); 
	
	$("#dialog").dialog("close");
}
function formatter(value,row,index) {
    return '<div style="width=250px;word-break:break-all;word-wrap:break-word;white-space:pre-wrap;">'+value+'</div>';
}