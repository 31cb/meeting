
$(function(){
	
	init();
	
	$("#search_btn").click(function(){
		var meetName = $('#meetName').val();
		var strStTime = $('#strStTime').val();
		var strEndTime = $('#strEndTime').val();
		var creatName = $('#creatName').val();
		$('#allList').datagrid({
			queryParams: {
				meetName: meetName,
				strStTime: strStTime,
				strEndTime: strEndTime,
				creatName: creatName
			}
		});
		var p = $('#allList').datagrid('getPager');  
		$(p).pagination({  
		    beforePageText: '第',//页数文本框前显示的汉字   
		    afterPageText: '页    共 {pages} 页',  
		    displayMsg: '第{from}到{to}条，共{total}条',  
		});
	});
	
	$("#look_btn").click(function(){
		var select = $("#allList").datagrid("getSelected");
		if(select == null){
			$.messager.alert('提示','请选择一条记录','error');
			return
		}
		$("#info").dialog("open");
		$("#infoForm").form("load",select);
	});
	
	
	$("#download_btn").click(function(){
		var select = $("#allList").datagrid("getSelected");
		if(select == null){
			$.messager.alert('提示','请选择一条会议记录','error');
			return
		}
		var pkid = select.pkid;
		$("#pkid").val(pkid);
		$.messager.confirm("下载","是否下载该会议附件!",function(r){
			if(r){
				$('#infoForm').form('submit', {
					url:"../all/download",
		            success:function(data){
		            	data = eval( '('+data+')' );
		            	if(data.status == 200){
		                	$.messager.alert('提示',data.description,'info');
		                }else{
		                	$.messager.alert('提示',data.description,'info');
		                }
		            }
				});
			}
		});
	});

	$("#info_close").click(function(){
		$("#info").dialog("close");
	});
	
})

function init(){
	
	$('#allList').datagrid({
		title: '会议列表',
		url: '../all/findAllList',
		method: 'post',
		striped: true,
		autoRowHeight:false,
		singleSelect:true,
		nowrap:false,
		columns : [ [ { 
		 	field : 'pkid', 
		 	width : '10%', 
		 	title:'ID',
		 	checkbox:true 
            },
            { 
           	 	field : 'meetName', 
           	 	title : '会议名称', 
           	 	width : '10%', 
           	 	align : 'center' 
			 },
			 { 
				 field : 'meetTheme', 
				 title : '会议主题', 
				 width : '10%', 
				 align : 'center', 
			 },
			 { 
				 field : 'creatName', 
				 title : '会议发起人', 
				 width : '10%', 
				 align : 'center', 
			 },
			 { 
				 field : 'strStTime', 
				 title : '开始时间', 
				 width : '15%', 
				 align : 'center', 
			 },
			 { 
				 field : 'strEndTime', 
				 title : '结束时间', 
				 width : '15%', 
				 align : 'center', 
			 },
			 { 
				 field : 'stName', 
				 title : '会议状态', 
				 width : '10%', 
				 align : 'center', 
			 },
			 { 
				 field : 'roomName', 
				 title : '会议地点', 
				 width : '10%', 
				 align : 'center', 
			 },
			{ 
				field : 'remark', 
				title : '备注', 
				width : '19%',
				align : 'left', 
			}
			] ],
		idField:'pkid', 
		loadMsg:'请稍候，数据加载中...', 
		emptyMsg:'查询数据为空...',
		pagination:true,
		pageSize:5,   //表格中每页显示的行数
		pageList:[5,10,15]
	});
	
	var p = $('#allList').datagrid('getPager');  
	$(p).pagination({  
	    beforePageText: '第',//页数文本框前显示的汉字   
	    afterPageText: '页    共 {pages} 页',  
	    displayMsg: '第{from}到{to}条，共{total}条',  
	}); 
	
	$("#info").dialog("close");
	loadRoom();
}
function formatter(value,row,index) {
    return '<div style="width=250px;word-break:break-all;word-wrap:break-word;white-space:pre-wrap;">'+value+'</div>';
}
function loadRoom(){
	$.ajax({
        url:"../all/findAllRoom",
        data:"",
        success:function(data){
            if(data.status == 200){
            	if(data.data!=null){
            		$("#edit_roomId").append("<option value='"+data.data[0].pkid+"' select='select' >"+data.data[0].roomName+"</option>");
            		for(var j=1;j<data.data.length;j++){
            		       $("#edit_roomId").append("<option value='"+data.data[j].pkid+"'>"+data.data[j].roomName+"</option>");
            		    }
            	}else{
            		$("#edit_roomId").append("<option>未添加会议室</option>");
            	}
            }else{
            	$.messager.alert('提示',data.description,'info');
            }
        }
	});
}