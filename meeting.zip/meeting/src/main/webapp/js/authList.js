
$(function(){
	
	init();
	
	$("#search_btn").click(function(){
		var username = $('#username').val();
		var name = $('#name').val();
		$('#authUserList').datagrid({
			queryParams: {
				username: username,
				name: name
			}
		});
		var p = $('#authUserList').datagrid('getPager');  
		$(p).pagination({  
		    beforePageText: '第',//页数文本框前显示的汉字   
		    afterPageText: '页    共 {pages} 页',  
		    displayMsg: '第{from}到{to}条，共{total}条',  
		});
	});
	
	$("#cancel_btn").click(function(){
		$("#dialog").dialog("close");
	});
	
	$("#auth_btn").click(function(){
		var select = $("#authUserList").datagrid("getSelected");
		if(select == null){
			$.messager.alert('提示','请选择一条记录','error');
			return
		}
		$("#dialog").dialog("open");
		$("#editForm").form("load",select);
		if(select.auth.length == 0){
			$("#addNo").attr("selected","selected");
			$("#lookNo").attr("selected","selected");
		}else if(select.auth.length ==1){
			if(select.auth[0] == "发布会议"){
				$("#addYes").attr("selected","selected");
				$("#lookNo").attr("selected","selected");
			}else if(select.auth[0] == "无"){
				$("#addNo").attr("selected","selected");
				$("#lookNo").attr("selected","selected");
			}else{
				$("#addNo").attr("selected","selected");
				$("#lookYes").attr("selected","selected");
			}
		}else{
			$("#addYes").attr("selected","selected");
			$("#lookYes").attr("selected","selected");
		}
	});
	
	$("#save_btn").click(function(){
		$('#editForm').form('submit', {
		    url:"../auth/updateUserAuth",
		    success: function(data){
		    	data = eval( '('+data+')' );
		    	if(data.status==200){
		    		$.messager.alert('提示',data.description,'info');
		    		$("#dialog").dialog("close");
		    		$('#authUserList').datagrid('reload');
		    	}else{
		    		$.messager.alert('提示',data.description,'info');
		    		$("#dialog").dialog("close");
		    	}
		    }
		});
	});	
	
})

function init(){
	
	$('#authUserList').datagrid({
		title: '用户列表',
		url: '../auth/findUserList',
		method: 'post',
		striped: true,
		autoRowHeight:false,
		singleSelect:true,
		nowrap:false,
		columns : [ [ { 
		 		field : 'pkid', //每一列的名字
		 		width : '10%', 
		 		title:'ID',
		 		checkbox:true 
            },
            { 
           	 	field : 'username', 
           	 	title : '用户名', 
           	 	width : '10%', 
           	 	align : 'center' 
			 },
			 { 
				 field : 'name', 
				 title : '姓名', 
				 width : '10%', 
				 align : 'center', 
			 },
			 { 
				 field : 'deptName', 
				 title : '部门', 
				 width : '12%', 
				 align : 'center', 
			 },
			 { 
				 field : 'roleName', 
				 title : '角色', 
				 width : '12%', 
				 align : 'center', 
			},
			 { 
				 field : 'auth', 
				 title : '所具有权限', 
				 width : '25%', 
				 align : 'center', 
			},
			{ 
				field : 'remark', 
				title : '备注', 
				width : '30%',
				align : 'center', 
			}
			] ],
		idField:'pkid', 
		loadMsg:'请稍候，数据加载中...', 
		emptyMsg:'查询数据为空...',
		pagination:true,
		pageSize:5,   //表格中每页显示的行数
		pageList:[5,10,15]
	});
	
	var p = $('#authUserList').datagrid('getPager');  
	$(p).pagination({  
	    beforePageText: '第',//页数文本框前显示的汉字   
	    afterPageText: '页    共 {pages} 页',  
	    displayMsg: '第{from}到{to}条，共{total}条',  
	}); 
	
	$("#dialog").dialog("close");
	
}
function formatter(value,row,index) {
    return '<div style="width=250px;word-break:break-all;word-wrap:break-word;white-space:pre-wrap;">'+value+'</div>';
}