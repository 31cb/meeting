package com.cb.meeting.bean.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/** 
  * @类名称 ： UserEntity.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年1月23日 上午10:20:30 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年1月23日上午10:20:30----新增 
  * @---------------------------------------- 
  */

@Entity
@Table(name="user")
public class UserEntity implements Serializable {

	private static final long serialVersionUID = -1607373568883009335L;
	
	/**
	 * 主键ID
	 */
	@Id
	@Column(name = "pkid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer pkid;
	
	/**
	 * 用户名
	 */
	@Column(name = "username")
	private String username;
		
	/**
	 * 密码
	 */
	@Column(name = "password")
	private String password;
	
	/**
	 * 姓名
	 */
	@Column(name = "name")
	private String name;
	
	/**
	 * 部门编号
	 */
	@Column(name = "dept_num")
	private String deptNum;
	
	/**
	 * 手机号码
	 */
	@Column(name = "phene_num")
	private String phoneNum;
	
	/**
	 * 邮件地址
	 */
	@Column(name = "email")
	private String email;
	
	/**
	 * 角色
	 */
	@Column(name = "role")
	private Integer role;
	
	/**
	 * 权限管理标志
	 */
	@Column(name = "auth_flag")
	private String authFlag;
	
	/**
	 * 激活状态
	 */
	@Column(name = "st")
	private String st;
	
	/**
	 * 备注
	 */
	@Column(name = "remark")
	private String remark;

	
	/** 
	* @return the pkid 
	*/
	
	public Integer getPkid() {
		return pkid;
	}

	
	/** 
	* @param pkid the pkid to set 
	*/
	
	public void setPkid(Integer pkid) {
		this.pkid = pkid;
	}

	
	/** 
	* @return the username 
	*/
	
	public String getUsername() {
		return username;
	}

	
	/** 
	* @param username the username to set 
	*/
	
	public void setUsername(String username) {
		this.username = username;
	}

	
	/** 
	* @return the password 
	*/
	
	public String getPassword() {
		return password;
	}

	
	/** 
	* @param password the password to set 
	*/
	
	public void setPassword(String password) {
		this.password = password;
	}


	
	/** 
	* @return the phoneNum 
	*/
	
	public String getPhoneNum() {
		return phoneNum;
	}


	
	/** 
	* @param phoneNum the phoneNum to set 
	*/
	
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}


	
	/** 
	* @return the email 
	*/
	
	public String getEmail() {
		return email;
	}


	
	/** 
	* @param email the email to set 
	*/
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	/** 
	* @return the role 
	*/
	
	public Integer getRole() {
		return role;
	}


	
	/** 
	* @param role the role to set 
	*/
	
	public void setRole(Integer role) {
		this.role = role;
	}


	/** 
	* @return the st 
	*/
	
	public String getSt() {
		return st;
	}


	
	/** 
	* @param st the st to set 
	*/
	
	public void setSt(String st) {
		this.st = st;
	}


	/** 
	* @return the remark 
	*/
	
	public String getRemark() {
		return remark;
	}


	
	/** 
	* @param remark the remark to set 
	*/
	
	public void setRemark(String remark) {
		this.remark = remark;
	}


	
	/** 
	* @return the name 
	*/
	
	public String getName() {
		return name;
	}


	
	/** 
	* @param name the name to set 
	*/
	
	public void setName(String name) {
		this.name = name;
	}


	
	/** 
	* @return the deptNum 
	*/
	
	public String getDeptNum() {
		return deptNum;
	}


	
	/** 
	* @param deptNum the deptNum to set 
	*/
	
	public void setDeptNum(String deptNum) {
		this.deptNum = deptNum;
	}


	
	/** 
	* @return the authFlag 
	*/
	
	public String getAuthFlag() {
		return authFlag;
	}


	
	/** 
	* @param authFlag the authFlag to set 
	*/
	
	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}
	
	
}
