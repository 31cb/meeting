
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月12日 
  * 创建时间: 上午11:15:44 
  */
  
package com.cb.meeting.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cb.meeting.bean.vo.MeetRoomVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.RoomVO;
import com.cb.meeting.dao.RoomDao;
import com.cb.meeting.service.RoomService;

/** 
  * @类名称 ： RoomServiceImpl.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月12日 上午11:15:44 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月12日上午11:15:44----新增 
  * @---------------------------------------- 
  */

@Service
@Transactional
public class RoomServiceImpl implements RoomService {

	@Autowired
	private RoomDao roomDao;
	
	@Override
	public List<RoomVO> findRoomList(PageVO<RoomVO> pageVO) throws Exception {
		List<RoomVO> list = new ArrayList<RoomVO>();
		try {
			list = roomDao.findRoomList(pageVO);
		} catch (Exception e) {
			throw e;
		}
		return list;
	}

	@Override
	public Integer findCount(PageVO<RoomVO> pageVO) throws Exception {
		Integer total = 0;
		try {
			total = roomDao.findCount(pageVO);
		} catch (Exception e) {
			throw e;
		}
		return total;
	}
	
	@Override
	public void addRoom(RoomVO roomVO) throws Exception {
		try {
			roomDao.addRoom(roomVO);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public void updateRoom(RoomVO roomVO) throws Exception {
		try {
			roomDao.updateRoom(roomVO);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public void deleteRoom(Integer pkid) throws Exception {
		try {
			roomDao.deleteRoom(pkid);
		} catch (Exception e) {
			throw e;
		}
	}
	  
	@Override
	public Integer existRoomNum(String roomNum) throws Exception {
		Integer exist = 0;
		try{
			 exist = roomDao.existRoomNum(roomNum);
		}catch(Exception e){
			throw e;
		}
		return exist;
	}

	@Override
	public Integer existRoomName(String roomName) throws Exception {
		Integer exist = 0;
		try{
			 exist = roomDao.existRoomName(roomName);
		}catch(Exception e){
			throw e;
		}
		return exist;
	}
	  
	@Override
	public Integer existRoomPlace(String roomPlace) throws Exception {
		Integer exist = 0;
		try{
			 exist = roomDao.existRoomPlace(roomPlace);
		}catch(Exception e){
			throw e;
		} 
		return exist;
	}
	  
	@Override
	public RoomVO findRoomById(Integer roomId) throws Exception {
		RoomVO roomVO = new RoomVO();
		try {
			roomVO = roomDao.findRoomById(roomId);
		} catch (Exception e) {
			throw e;
		}
		return roomVO;
	}

	@Override
	public List<MeetRoomVO> findAllRoom() throws Exception {
		List<MeetRoomVO> list = new ArrayList<MeetRoomVO>();
		try {
			list = roomDao.findAllRoom();
		} catch (Exception e) {
			throw e;
		}
		return list;
	}
	  
	@Override
	public boolean roomAvailable(MeetRoomVO meetRoomVO) throws Exception {
		List<MeetRoomVO> list = new ArrayList<MeetRoomVO>();
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
		try{
			list = roomDao.roomAvailable(meetRoomVO);
			for(MeetRoomVO vo : list){
				long mvost = formatter.parse(meetRoomVO.getStrStTime()).getTime();
				long mvoet = formatter.parse(meetRoomVO.getStrEndTime()).getTime();
				long vost = formatter.parse(vo.getStrStTime()).getTime();
				long voet = formatter.parse(vo.getStrEndTime()).getTime();
				if( (mvost >= vost && mvoet < voet) || (mvoet > vost && mvoet <=voet) )
					return false;
			}
			return true;
		}catch (Exception e){
			throw e;
		}
	}
	
}
