package com.cb.meeting.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cb.meeting.bean.vo.MeetUserVO;
import com.cb.meeting.bean.vo.MeetVO;
import com.cb.meeting.bean.vo.MessageVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.dao.MeetDao;
import com.cb.meeting.dao.MessageDao;
import com.cb.meeting.service.MessageService;

@Service
public class MessageServiceImpl implements MessageService {

	@Autowired
	private MessageDao messageDao;
	
	@Autowired
	private MeetDao meetDao;
	
	@Override
	public void addMessage(MessageVO messageVO) throws Exception {
		try{
			messageDao.addMessage(messageVO);
		}catch(Exception e){
			throw e;
		}
	}

	  
	@Override
	public List<MessageVO> findMsgByMeetId(Integer meetId) throws Exception {
		List<MessageVO> list = new ArrayList<MessageVO>();
		try {
			list = messageDao.findMsgByMeetId(meetId);
		} catch (Exception e) {
			throw e;
		}
		return list;
	}
	  
	@Override
	public void updateMsgSt(Integer meetId) throws Exception {
		try {
			messageDao.updateMsgSt(meetId);
		} catch (Exception e) {
			throw e;
		}
		
	}
	  
	@Override
	public Integer findUnreadMessageCount(Integer userId) throws Exception {
		Integer count = 0;
		try {
			count = messageDao.findUnreadMessageCount(userId);
		} catch (Exception e) {
			throw e;
		}
		return count;
	}
	  
	@Override
	public List<MeetVO> findMeetList(PageVO<MeetVO> pageVO) throws Exception {
		List<MeetVO> list = new ArrayList<MeetVO>();
		try {
			list = meetDao.findMeetList(pageVO);
			for(MeetVO vo : list){
				String meetRyId = "";
				String meetRyName = "";
				List<MeetUserVO> meetUserVOs = meetDao.findMeetUser(vo.getPkid());
				if(meetUserVOs != null && meetUserVOs.size() != 0){
					meetRyId = meetUserVOs.get(0).getMeetUserId().toString();
					meetRyName = meetUserVOs.get(0).getMeetUserName();
					for(int i = 1;i<meetUserVOs.size();i++){
						meetRyId = meetRyId + "," + meetUserVOs.get(i).getMeetUserId();
						meetRyName = meetRyName + "," + meetUserVOs.get(i).getMeetUserName();
					}
				}
				vo.setMeetRy(meetRyId);
				vo.setMeetRyName(meetRyName);
				Long messageCount = messageDao.findMessageCount(vo.getPkid());
				Long replyCount = messageDao.findReplyCount(vo.getPkid());
				vo.setMessageCount(messageCount);
				vo.setReplyCount(replyCount);
			}
		} catch (Exception e) {
			throw e;
		}
		return list;
	}

}
