package com.cb.meeting.bean.vo;

import java.io.Serializable;

/** 
  * @类名称 ： ResponseVO.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年1月23日 上午10:47:56 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年1月23日上午10:47:56----新增 
  * @---------------------------------------- 
  */

public class ResponseVO implements Serializable{
	
	private static final long serialVersionUID = -5758277661040523439L;
	
	public static final int ERROR = 100;
	public static final int OK = 200;
	private int status;
	private String description;
	private Object data;

	public int getStatus() {
		return this.status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Object getData() {
		return this.data;
	}

	public void setData(Object data) {
		this.data = data;
	}
}
