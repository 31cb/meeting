
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年4月8日 
  * 创建时间: 上午8:49:52 
  */
  
package com.cb.meeting.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cb.meeting.bean.vo.MeetUserVO;
import com.cb.meeting.bean.vo.MeetVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.dao.AllDao;
import com.cb.meeting.dao.MeetDao;
import com.cb.meeting.service.AllService;

/** 
  * @类名称 ： AllListServiceImpl.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年4月8日 上午8:49:52 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年4月8日上午8:49:52----新增 
  * @---------------------------------------- 
  */

@Service
public class AllServiceImpl implements AllService {

	@Autowired
	private AllDao allDao;

	@Autowired
	private MeetDao meetDao;
	
	@Override
	public List<MeetVO> findAllList(PageVO<MeetVO> pageVO) throws Exception {
		List<MeetVO> list = new ArrayList<MeetVO>();
		try {
			list = allDao.findAllList(pageVO);
			for(MeetVO vo : list){
				String meetRyId = "";
				String meetRyName = "";
				List<MeetUserVO> meetUserVOs = meetDao.findMeetUser(vo.getPkid());
				if(meetUserVOs != null && meetUserVOs.size() != 0){
					meetRyId = meetUserVOs.get(0).getMeetUserId().toString();
					meetRyName = meetUserVOs.get(0).getMeetUserName();
					for(int i = 1;i<meetUserVOs.size();i++){
						meetRyId = meetRyId + "," + meetUserVOs.get(i).getMeetUserId();
						meetRyName = meetRyName + "," + meetUserVOs.get(i).getMeetUserName();
					}
				}
				vo.setMeetRy(meetRyId);
				vo.setMeetRyName(meetRyName);
			}
		} catch (Exception e) {
			throw e;
		}
		return list;
	}

	@Override
	public Integer findCount(PageVO<MeetVO> pageVO) throws Exception {
		Integer total = 0;
		try {
			total = allDao.findCount(pageVO);
		} catch (Exception e) {
			throw e;
		}
		return total;
	}

}
