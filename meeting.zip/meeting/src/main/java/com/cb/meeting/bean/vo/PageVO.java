
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年2月25日 
  * 创建时间: 下午3:18:55 
  */
  
package com.cb.meeting.bean.vo;

import java.io.Serializable;

/** 
  * @类名称 ： PageVO.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月25日 下午3:18:55 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月25日下午3:18:55----新增 
  * @---------------------------------------- 
  */

public class PageVO<T> implements Serializable{

	private static final long serialVersionUID = -659028126446633472L;
	
	private Integer page;
	private Integer rows;
	private T queryParam;
	private Integer startPage;
	private Integer total;
	
	
	
	/** 
	* @return the total 
	*/
	
	public Integer getTotal() {
		return total;
	}



	
	/** 
	* @param total the total to set 
	*/
	
	public void setTotal(Integer total) {
		this.total = total;
	}



	/** 
	* @return the startPage 
	*/
	
	public Integer getStartPage() {
		return startPage;
	}


	
	/** 
	* @param startPage the startPage to set 
	*/
	
	public void setStartPage(Integer startPage) {
		this.startPage = startPage;
	}


	/** 
	* @return the page 
	*/
	
	public Integer getPage() {
		return page;
	}

	
	/** 
	* @param page the page to set 
	*/
	
	public void setPage(Integer page) {
		this.page = page;
	}

	
	/** 
	* @return the rows 
	*/
	
	public Integer getRows() {
		return rows;
	}

	
	/** 
	* @param rows the rows to set 
	*/
	
	public void setRows(Integer rows) {
		this.rows = rows;
	}

	/** 
	* @return the queryParam 
	*/
	
	public T getQueryParam() {
		return queryParam;
	}
	
	/** 
	* @param queryParam the queryParam to set 
	*/
	
	public void setQueryParam(T queryParam) {
		this.queryParam = queryParam;
	}
	
	
}
