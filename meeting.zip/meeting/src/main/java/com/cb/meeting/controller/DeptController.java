package com.cb.meeting.controller;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cb.meeting.bean.vo.DataGridVO;
import com.cb.meeting.bean.vo.DeptVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.ResponseVO;
import com.cb.meeting.service.DeptService;


/** 
  * @类名称 ： roomController.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月22日 下午3:13:05 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月22日下午3:13:05----新增 
  * @---------------------------------------- 
  */

@Controller
@RequestMapping(value="/dept")
public class DeptController {
	
	@Autowired
	private DeptService deptService;

	@RequestMapping("/page")
	public String page(){
		return "deptList";
	}
	
	@RequestMapping("/findDeptList")
	@ResponseBody
	public DataGridVO<DeptVO> findDeptList(PageVO<DeptVO> pageVO,DeptVO deptVO){
		DataGridVO<DeptVO> dataGridVO = new DataGridVO<DeptVO>();
		pageVO.setQueryParam(deptVO);
		pageVO.setStartPage((pageVO.getPage()-1)*pageVO.getRows());
		List<DeptVO> list = new ArrayList<DeptVO>();
		try {
			list = deptService.findDeptList(pageVO);
			Integer total = deptService.findCount(pageVO);
			dataGridVO.setTotal(total);
			dataGridVO.setRows(list);
		} catch (Exception e) {
			dataGridVO.setTotal(0);
			dataGridVO.setRows(list);
		}
		
		return dataGridVO;
	}
	
	@RequestMapping("/addOrUpdate")
	@ResponseBody
	public ResponseVO addOrUpdate(DeptVO deptVO){
		ResponseVO responseVO = new ResponseVO();
		if(deptVO.getPkid() == null){
			try {
				deptService.addDept(deptVO);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("增加部门成功");
			} catch (Exception e) {
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("增加部门失败");
			}
		}else {
			try {
				deptService.updateDept(deptVO);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("修改部门成功");
			} catch (Exception e) {
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("修改部门失败");
			}
		}
		return responseVO;
	}
	
	@RequestMapping("/deleteDept")
	@ResponseBody
	public ResponseVO deleteDept(Integer pkid){
		ResponseVO responseVO = new ResponseVO();
		try {
			deptService.deleteDept(pkid);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("删除部门成功");
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("删除部门失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/existDeptNum")
	@ResponseBody
	public ResponseVO existDeptNum(String deptNum){
		ResponseVO responseVO = new ResponseVO();
		try {
			Integer exist = deptService.existDeptNum(deptNum);
			if(exist == 0){
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("部门编号不存在");
			}else{
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("部门已存在,请修改!");
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		}

		return responseVO;
	}
	
	@RequestMapping("/existDeptName")
	@ResponseBody
	public ResponseVO existDeptName(String deptName){
		ResponseVO responseVO = new ResponseVO();
		try {
			Integer exist = deptService.existDeptName(deptName);
			if(exist == 0){
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("部门名称不存在");
			}else{
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("部门名称已存在,请修改!");
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		}

		return responseVO;
	}
	
}
