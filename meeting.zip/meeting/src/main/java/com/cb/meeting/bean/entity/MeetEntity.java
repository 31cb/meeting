package com.cb.meeting.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** 
  * @类名称 ： RoomEntity.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月12日 上午9:21:34 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月12日上午9:21:34----新增 
  * @---------------------------------------- 
  */

@Entity
@Table(name="meet")
public class MeetEntity implements Serializable {

	private static final long serialVersionUID = -4366657207516087143L;

	/**
	 * 主键ID
	 */
	@Id
	@Column(name = "pkid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer pkid;
	
	/**
	 * 会议名称
	 */
	@Column(name = "meet_name")
	private String meetName;
		
	/**
	 * 会议开始时间
	 */
	@Column(name = "meet_start_time")
	private Timestamp meetStartTime;
	
	/**
	 * 会议结束时间
	 */
	@Column(name = "meet_end_time")
	private Timestamp meetEndTime;
	
	/**
	 * 创建时间
	 */
	@Column(name = "creat_time")
	private Timestamp creatTime;
	
	/**
	 * 最后更新时间
	 */
	@Column(name = "last_update_time")
	private Timestamp lastUpdateTime;
	
	/**
	 * 创建人
	 */
	@Column(name = "creat_user")
	private Integer creatUser;
	
	/**
	 * 会议主题
	 */
	@Column(name = "meet_theme")
	private String meetTheme;
	
	/**
	 * 会议描述
	 */
	@Column(name = "meet_des")
	private String meetDes;
	
	/**
	 * 附件路径
	 */
	@Column(name = "meet_attach_path")
	private String meetAttachPath;
	
	/**
	 * 会议状态
	 */
	@Column(name = "meet_st")
	private String meetSt;
	
	/**
	 * 会议室
	 */
	@Column(name = "meet_room_id")
	private Integer meetRoomId;
	
	/**
	 * 发送标志
	 */
	@Column(name = "send_flag")
	private String sendFlag;
	
	/**
	 * 备注
	 */
	@Column(name = "remark")
	private String remark;

	
	/** 
	* @return the pkid 
	*/
	
	public Integer getPkid() {
		return pkid;
	}

	
	/** 
	* @param pkid the pkid to set 
	*/
	
	public void setPkid(Integer pkid) {
		this.pkid = pkid;
	}

	
	/** 
	* @return the meetName 
	*/
	
	public String getMeetName() {
		return meetName;
	}

	
	/** 
	* @param meetName the meetName to set 
	*/
	
	public void setMeetName(String meetName) {
		this.meetName = meetName;
	}

	
	/** 
	* @return the meetStartTime 
	*/
	
	public Timestamp getMeetStartTime() {
		return meetStartTime;
	}

	
	/** 
	* @param meetStartTime the meetStartTime to set 
	*/
	
	public void setMeetStartTime(Timestamp meetStartTime) {
		this.meetStartTime = meetStartTime;
	}

	
	/** 
	* @return the meetEndTime 
	*/
	
	public Timestamp getMeetEndTime() {
		return meetEndTime;
	}

	
	/** 
	* @param meetEndTime the meetEndTime to set 
	*/
	
	public void setMeetEndTime(Timestamp meetEndTime) {
		this.meetEndTime = meetEndTime;
	}

	
	/** 
	* @return the creatTime 
	*/
	
	public Timestamp getCreatTime() {
		return creatTime;
	}

	
	/** 
	* @param creatTime the creatTime to set 
	*/
	
	public void setCreatTime(Timestamp creatTime) {
		this.creatTime = creatTime;
	}

	
	/** 
	* @return the lastUpdateTime 
	*/
	
	public Timestamp getLastUpdateTime() {
		return lastUpdateTime;
	}

	
	/** 
	* @param lastUpdateTime the lastUpdateTime to set 
	*/
	
	public void setLastUpdateTime(Timestamp lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	
	/** 
	* @return the creatUser 
	*/
	
	public Integer getCreatUser() {
		return creatUser;
	}

	
	/** 
	* @param creatUser the creatUser to set 
	*/
	
	public void setCreatUser(Integer creatUser) {
		this.creatUser = creatUser;
	}

	
	/** 
	* @return the meetTheme 
	*/
	
	public String getMeetTheme() {
		return meetTheme;
	}

	
	/** 
	* @param meetTheme the meetTheme to set 
	*/
	
	public void setMeetTheme(String meetTheme) {
		this.meetTheme = meetTheme;
	}

	
	/** 
	* @return the meetDes 
	*/
	
	public String getMeetDes() {
		return meetDes;
	}

	
	/** 
	* @param meetDes the meetDes to set 
	*/
	
	public void setMeetDes(String meetDes) {
		this.meetDes = meetDes;
	}

	
	/** 
	* @return the meetAttachPath 
	*/
	
	public String getMeetAttachPath() {
		return meetAttachPath;
	}

	
	/** 
	* @param meetAttachPath the meetAttachPath to set 
	*/
	
	public void setMeetAttachPath(String meetAttachPath) {
		this.meetAttachPath = meetAttachPath;
	}

	
	/** 
	* @return the remark 
	*/
	
	public String getRemark() {
		return remark;
	}

	
	/** 
	* @param remark the remark to set 
	*/
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	/** 
	* @return the meetSt 
	*/
	
	public String getMeetSt() {
		return meetSt;
	}
	
	/** 
	* @param meetSt the meetSt to set 
	*/
	
	public void setMeetSt(String meetSt) {
		this.meetSt = meetSt;
	}


	
	/** 
	* @return the meetRoomId 
	*/
	
	public Integer getMeetRoomId() {
		return meetRoomId;
	}

	/** 
	* @param meetRoomId the meetRoomId to set 
	*/
	
	public void setMeetRoomId(Integer meetRoomId) {
		this.meetRoomId = meetRoomId;
	}


	public String getSendFlag() {
		return sendFlag;
	}


	public void setSendFlag(String sendFlag) {
		this.sendFlag = sendFlag;
	}

	
}
