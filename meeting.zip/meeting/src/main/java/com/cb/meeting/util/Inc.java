
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年6月6日 
  * 创建时间: 下午4:44:26 
  */
  
package com.cb.meeting.util;

import org.aspectj.internal.lang.annotation.ajcDeclareAnnotation;
import org.springframework.util.StringUtils;

/** 
  * @类名称 ： Inc.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年6月6日 下午4:44:26 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年6月6日下午4:44:26----新增 
  * @---------------------------------------- 
  */

public class Inc {

	/** 
	  * @方法名称 ：main 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param args 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */


    public static void main (String[]  args){
    	
    	A a = new B();
    	a.say();
    	a.sing();
    	A a1 = new A();
    	a1.say();
    	a.sing();
    	B b = new B();
    	b.say();
    	b.sing();
    	b.run();
    }
}
class A{
	public void say() {
		System.out.println("a");
	}
	public void sing() {
		System.out.println("sing");
	}
}
class B extends A{
	public void say() {
		System.out.println("b");
	}
	public void run() {
		System.out.println("run");
	}
}
