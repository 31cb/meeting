
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年2月22日 
  * 创建时间: 下午2:30:43 
  */
  
package com.cb.meeting.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cb.meeting.bean.entity.UserEntity;
import com.cb.meeting.bean.vo.DeptVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.UserVO;
import com.cb.meeting.dao.UserDao;
import com.cb.meeting.service.UserService;

/** 
  * @类名称 ： UserServiceImpl.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月22日 下午2:30:43 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月22日下午2:30:43----新增 
  * @---------------------------------------- 
  */
@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	  
	@Override
	public List<UserVO> findUserList(PageVO<UserVO> pageVO) throws Exception {
		List<UserVO> list = new ArrayList<UserVO>();
		try {
			list = userDao.findUserList(pageVO);
		} catch (Exception e) {
			throw e;
		}
		return list;
	}

	  
	@Override
	public Integer findCount(PageVO<UserVO> pageVO) throws Exception {
		Integer total = 0;
		try {
			total = userDao.findCount(pageVO);
		} catch (Exception e) {
			throw e;
		}
		return total;
	}
	
	@Override
	public void addUser(UserVO userVO) throws Exception {
		try {
			userDao.addUser(userVO);
		} catch (Exception e) {
			throw e;
		}
	}

	  
	@Override
	public Integer existUsername(String username) throws Exception {
		Integer exist = 0;
		try{
			 exist = userDao.existUsername(username);
		}catch(Exception e){
			throw e;
		}
		return exist;
	}

	@Override
	public void updateUser(UserVO userVO) throws Exception {
		try {
			userDao.updateUser(userVO);
		} catch (Exception e) {
			throw e;
		}
	}
	  
	@Override
	public void deleteUser(Integer pkid) throws Exception {
		try {
			userDao.deleteUser(pkid);
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Override
	public void deleteActive(Integer pkid) throws Exception {
		try {
			userDao.deleteActive(pkid);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public List<DeptVO> findAllDept() throws Exception {
		List<DeptVO> list = new ArrayList<DeptVO>();
		try {
			list = userDao.findAllDept();
		} catch (Exception e) {
			throw e;
		}
		return list;
	}
	  
	@Override
	public UserEntity findUserById(Integer pkid) throws Exception {
		UserEntity user = new UserEntity();
		try {
			user = userDao.findUserById();
		} catch (Exception e) {
			throw e;
		}
		return user;
	}

}
