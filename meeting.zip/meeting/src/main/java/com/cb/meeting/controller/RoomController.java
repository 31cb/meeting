package com.cb.meeting.controller;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cb.meeting.bean.vo.DataGridVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.ResponseVO;
import com.cb.meeting.bean.vo.RoomVO;
import com.cb.meeting.service.RoomService;


/** 
  * @类名称 ： roomController.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月22日 下午3:13:05 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月22日下午3:13:05----新增 
  * @---------------------------------------- 
  */

@Controller
@RequestMapping(value="/room")
public class RoomController {
	
	@Autowired
	private RoomService roomService;

	@RequestMapping("/page")
	public String page(){
		return "roomList";
	}
	
	@RequestMapping("/room")
	public String room(){
		return "roomPage";
	}
	
	@RequestMapping("/findRoomList")
	@ResponseBody
	public DataGridVO<RoomVO> findRoomList(PageVO<RoomVO> pageVO,RoomVO roomVO){
		DataGridVO<RoomVO> dataGridVO = new DataGridVO<RoomVO>();
		pageVO.setQueryParam(roomVO);
		pageVO.setStartPage((pageVO.getPage()-1)*pageVO.getRows());
		List<RoomVO> list = new ArrayList<RoomVO>();
		try {
			list = roomService.findRoomList(pageVO);
			Integer total = roomService.findCount(pageVO);
			dataGridVO.setTotal(total);
			dataGridVO.setRows(list);
		} catch (Exception e) {
			dataGridVO.setTotal(0);
			dataGridVO.setRows(list);
		}
		
		return dataGridVO;
	}
	
	@RequestMapping("/addOrUpdate")
	@ResponseBody
	public ResponseVO addOrUpdate(RoomVO roomVO){
		ResponseVO responseVO = new ResponseVO();
		if(roomVO.getPkid() == null){
			roomVO.setRoomSt("0");
			try {
				roomService.addRoom(roomVO);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("增加会议室成功");
			} catch (Exception e) {
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("增加会议室失败");
			}
		}else {
			try {
				roomService.updateRoom(roomVO);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("修改会议室成功");
			} catch (Exception e) {
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("修改会议室失败");
			}
		}
		return responseVO;
	}
	
	@RequestMapping("/deleteRoom")
	@ResponseBody
	public ResponseVO deleteRoom(Integer pkid){
		ResponseVO responseVO = new ResponseVO();
		try {
			roomService.deleteRoom(pkid);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("删除会议室成功");
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("删除会议室失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/existRoomNum")
	@ResponseBody
	public ResponseVO existRoomNum(String roomNum){
		ResponseVO responseVO = new ResponseVO();
		try {
			Integer exist = roomService.existRoomNum(roomNum);
			if(exist == 0){
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("会议室编号不存在");
			}else{
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("会议室编号已存在,请修改!");
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		}

		return responseVO;
	}
	
	@RequestMapping("/existRoomName")
	@ResponseBody
	public ResponseVO existRoomName(String roomName){
		ResponseVO responseVO = new ResponseVO();
		try {
			Integer exist = roomService.existRoomName(roomName);
			if(exist == 0){
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("会议室名称不存在");
			}else{
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("会议室名称已存在,请修改!");
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		}

		return responseVO;
	}
	
	@RequestMapping("/existRoomPlace")
	@ResponseBody
	public ResponseVO existRoomPlace(String roomPlace){
		ResponseVO responseVO = new ResponseVO();
		try {
			Integer exist = roomService.existRoomPlace(roomPlace);
			if(exist == 0){
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("会议室地点不存在");
			}else{
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("该地点已存在,请确认输入无误!");
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		}

		return responseVO;
	}
	
}
