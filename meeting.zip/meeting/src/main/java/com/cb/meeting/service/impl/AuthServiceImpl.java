
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月15日 
  * 创建时间: 上午10:54:27 
  */
  
package com.cb.meeting.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cb.meeting.bean.vo.AuthVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.UserVO;
import com.cb.meeting.dao.AuthDao;
import com.cb.meeting.service.AuthService;

/** 
  * @类名称 ： AuthServiceImpl.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月15日 上午10:54:27 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月15日上午10:54:27----新增 
  * @---------------------------------------- 
  */

@Service
@Transactional
public class AuthServiceImpl implements AuthService {

	@Autowired
	private AuthDao authDao;
	
	@Override
	public List<UserVO> findUserList(PageVO<UserVO> pageVO) throws Exception {
		List<UserVO> list = new ArrayList<UserVO>();
		try {
			list = authDao.findUserList(pageVO);
			for(UserVO uVo:list){
				List<String> auth = authDao.findUserAuthById(uVo.getPkid());
				if(auth == null || auth.isEmpty()){
					auth.add("无");
				}
				uVo.setAuth(auth);
			}
		} catch (Exception e) {
			throw e;
		}
		return list;
	}

	@Override
	public void updateUserAuth(AuthVO authVO) throws Exception {
		try {
			if("1".equals(authVO.getAuthAddMeet())){
				authDao.deleteAuthAddMeet(authVO.getPkid());
				authDao.addAuthAddMeet(authVO.getPkid());
			}else if ("0".equals(authVO.getAuthAddMeet())) {
				authDao.deleteAuthAddMeet(authVO.getPkid());
			}
			if("1".equals(authVO.getAuthLookMeet())){
				authDao.deleteAuthLookeet(authVO.getPkid());
				authDao.addAuthLookMeet(authVO.getPkid());
			}else if ("0".equals(authVO.getAuthLookMeet())) {
				authDao.deleteAuthLookeet(authVO.getPkid());
			}
		} catch (Exception e) {
			throw e;
		}
	}
		
}
