
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月14日 
  * 创建时间: 上午11:15:45 
  */
  
package com.cb.meeting.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cb.meeting.bean.vo.DeptVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.dao.DeptDao;
import com.cb.meeting.service.DeptService;

/** 
  * @类名称 ： DeptServiceImpl.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月14日 上午11:15:45 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月14日上午11:15:45----新增 
  * @---------------------------------------- 
  */

@Service
@Transactional
public class DeptServiceImpl implements DeptService {

	@Autowired
	private DeptDao deptDao;
	
	@Override
	public List<DeptVO> findDeptList(PageVO<DeptVO> pageVO) throws Exception {
		List<DeptVO> list = new ArrayList<DeptVO>();
		try {
			list = deptDao.findDeptList(pageVO);
		} catch (Exception e) {
			throw e;
		}
		return list;
	}

	@Override
	public Integer findCount(PageVO<DeptVO> pageVO) throws Exception {
		Integer total = 0;
		try {
			total = deptDao.findCount(pageVO);
		} catch (Exception e) {
			throw e;
		}
		return total;
	}

	@Override
	public void addDept(DeptVO deptVO) throws Exception {
		try {
			deptDao.addDept(deptVO);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public void updateDept(DeptVO deptVO) throws Exception {
		try {
			deptDao.updateDept(deptVO);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public void deleteDept(Integer pkid) throws Exception {
		try {
			deptDao.deleteDept(pkid);
		} catch (Exception e) {
			throw e;
		}
	}
	  
	@Override
	public Integer existDeptNum(String deptNum) throws Exception {
		Integer exist = 0;
		try{
			 exist = deptDao.existDeptNum(deptNum);
		}catch(Exception e){
			throw e;
		} 
		return exist;
	}
  
	@Override
	public Integer existDeptName(String deptName) throws Exception {
		Integer exist = 0;
		try{
			 exist = deptDao.existDeptName(deptName);
		}catch(Exception e){
			throw e;
		} 
		return exist;
	}

}
