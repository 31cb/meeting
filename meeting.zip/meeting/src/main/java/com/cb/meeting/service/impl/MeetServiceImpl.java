
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月14日 
  * 创建时间: 上午11:15:45 
  */
  
package com.cb.meeting.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cb.meeting.bean.vo.MeetRoomVO;
import com.cb.meeting.bean.vo.MeetUserVO;
import com.cb.meeting.bean.vo.MeetVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.UserVO;
import com.cb.meeting.dao.MeetDao;
import com.cb.meeting.service.MeetService;

/** 
  * @类名称 ： DeptServiceImpl.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月14日 上午11:15:45 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月14日上午11:15:45----新增 
  * @---------------------------------------- 
  */

@Service
@Transactional
public class MeetServiceImpl implements MeetService {

	@Autowired
	private MeetDao meetDao;
	
	@Override
	public List<MeetVO> findMeetList(PageVO<MeetVO> pageVO) throws Exception {
		List<MeetVO> list = new ArrayList<MeetVO>();
		try {
			list = meetDao.findMeetList(pageVO);
			for(MeetVO vo : list){
				String meetRyId = "";
				String meetRyName = "";
				List<MeetUserVO> meetUserVOs = meetDao.findMeetUser(vo.getPkid());
				if(meetUserVOs != null && meetUserVOs.size() != 0){
					meetRyId = meetUserVOs.get(0).getMeetUserId().toString();
					meetRyName = meetUserVOs.get(0).getMeetUserName();
					for(int i = 1;i<meetUserVOs.size();i++){
						meetRyId = meetRyId + "," + meetUserVOs.get(i).getMeetUserId();
						meetRyName = meetRyName + "," + meetUserVOs.get(i).getMeetUserName();
					}
				}
				vo.setMeetRy(meetRyId);
				vo.setMeetRyName(meetRyName);
			}
		} catch (Exception e) {
			throw e;
		}
		return list;
	}

	@Override
	public Integer findCount(PageVO<MeetVO> pageVO) throws Exception {
		Integer total = 0;
		try {
			total = meetDao.findCount(pageVO);
		} catch (Exception e) {
			throw e;
		}
		return total;
	}

	@Override
	public void addMeet(MeetVO meetVO) throws Exception {
		try {
			meetDao.addMeet(meetVO);
			Integer meetPkid = meetVO.getPkid();
			if(!"".equals(meetVO.getMeetRy())){
				String[] selectUser = meetVO.getMeetRy().split(",");
				for(String strPkid:selectUser ){
					Integer userPkid = Integer.valueOf(strPkid);
					meetDao.addUserMeet(userPkid,meetPkid);
				}
			}
			MeetRoomVO meetRoomVO = new MeetRoomVO();
			meetRoomVO.setMeetId(meetPkid);
			meetRoomVO.setMeetRoomId(meetVO.getMeetRoomId());
			meetRoomVO.setStrStTime(meetVO.getStrStTime());
			meetRoomVO.setStrEndTime(meetVO.getStrEndTime());
			meetDao.addMeetRoom(meetRoomVO);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public void updateMeet(MeetVO meetVO) throws Exception {
		try {
			meetDao.updateMeet(meetVO);
			meetDao.deleteUserMeet(meetVO.getPkid());
			if(!"".equals(meetVO.getMeetRy())){
				String[] selectUser = meetVO.getMeetRy().split(",");
				for(String strPkid:selectUser ){
					Integer userPkid = Integer.valueOf(strPkid);
					meetDao.addUserMeet(userPkid,meetVO.getPkid());
				}
			}
			MeetRoomVO meetRoomVO = new MeetRoomVO();
			meetRoomVO.setMeetId(meetVO.getPkid());
			meetRoomVO.setMeetRoomId(meetVO.getMeetRoomId());
			meetRoomVO.setStrStTime(meetVO.getStrStTime());
			meetRoomVO.setStrEndTime(meetVO.getStrEndTime());
			meetDao.updateMeetRoom(meetRoomVO);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public void deleteMeet(Integer pkid) throws Exception {
		try {
			meetDao.deleteMeet(pkid);
			meetDao.deleteUserMeet(pkid);
			meetDao.deleteMeetRoom(pkid);
		} catch (Exception e) {
			throw e;
		}
	}
	  
	
	  
	@Override
	public void updateMeetStByTime(Timestamp timestamp) throws Exception {
		try {
			meetDao.updateMeetStByTime(timestamp);
		} catch (Exception e) {
			throw e;
		}
	}
	  
	@Override
	public MeetVO findMeetById(Integer pkid) throws Exception {
		MeetVO meetVO = new MeetVO();
		try {
			meetVO = meetDao.findMeetById(pkid);
		} catch (Exception e) {
			Exception exception = new Exception("查询会议失败");
			exception = e ;
			throw exception;
		}
		return meetVO;
	}
	  
	@Override
	public void updateMeetEnd(MeetVO meetVO) throws Exception {
		try {
			meetDao.updateMeetEnd(meetVO);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public List<UserVO> findUserListByMeetId(Integer pkid) throws Exception {
		List<UserVO> userVO = new ArrayList<UserVO>();
		try {
			userVO = meetDao.findUserListByMeetId(pkid);
		} catch (Exception e) {
			Exception exception = new Exception("查询参会人员失败");
			exception = e ;
			throw exception;
		}
		return userVO;
	}
	  
	@Override
	public UserVO findCreatUser(Integer pkid) throws Exception {
		UserVO creatUser = new UserVO();
		try {
			creatUser = meetDao.findCreatUser(pkid);
		} catch (Exception e) {
			Exception exception = new Exception("查询发起人失败");
			exception = e ;
			throw exception;
		}
		return creatUser;
	}

	@Override
	public Integer findPendMeetCount(Integer pkid) throws Exception {
		Integer count = 0;
		try {
			count = meetDao.findPendMeetCount(pkid);
		} catch (Exception e) {
			throw e;
		}
		return count;
	}
	  
	@Override
	public void updateMeetSendFlag(Integer pkid) throws Exception {
		try{
			meetDao.updateMeetSendFlag(pkid);
		}catch(Exception e){
			throw e;
		}
	}
	  
}
