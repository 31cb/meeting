
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月22日 
  * 创建时间: 上午9:23:58 
  */
  
package com.cb.meeting.bean.vo;

import java.io.Serializable;

/** 
  * @类名称 ： MeetRoomVO.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月22日 上午9:23:58 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月22日上午9:23:58----新增 
  * @---------------------------------------- 
  */

public class MeetRoomVO extends RoomVO implements Serializable {

	private static final long serialVersionUID = 1460100129010174288L;

	private Integer meetId;
	private Integer meetRoomId;
	private String strStTime;
	private String strEndTime;
	
	public Integer getMeetId() {
		return meetId;
	}

	public void setMeetId(Integer meetId) {
		this.meetId = meetId;
	}
	
	public Integer getMeetRoomId() {
		return meetRoomId;
	}

	public void setMeetRoomId(Integer meetRoomId) {
		this.meetRoomId = meetRoomId;
	}

	public String getStrStTime() {
		return strStTime;
	}
	
	public void setStrStTime(String strStTime) {
		this.strStTime = strStTime;
	}
	
	public String getStrEndTime() {
		return strEndTime;
	}
	
	public void setStrEndTime(String strEndTime) {
		this.strEndTime = strEndTime;
	}
	
}
