
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月18日 
  * 创建时间: 上午10:40:11 
  */
  
package com.cb.meeting.bean.vo;

import com.cb.meeting.bean.entity.MeetEntity;

/** 
  * @类名称 ： MeetVO.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月18日 上午10:40:11 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月18日上午10:40:11----新增 
  * @---------------------------------------- 
  */

public class MeetVO extends MeetEntity {

	private static final long serialVersionUID = -2672312955267169754L;

	private String strStTime;
	private String strEndTime;
	private String meetRy;
	private String meetRyName;
	private String creatName;
	private String stName;
	private String roomName;
	private String roomPlace;
	private Long messageCount;
	private Long replyCount;
	
	public String getStrStTime() {
		return strStTime;
	}
	
	public void setStrStTime(String strStTime) {
		this.strStTime = strStTime;
	}
	
	public String getStrEndTime() {
		return strEndTime;
	}
	
	public void setStrEndTime(String strEndTime) {
		this.strEndTime = strEndTime;
	}

	public String getMeetRy() {
		return meetRy;
	}
	
	public void setMeetRy(String meetRy) {
		this.meetRy = meetRy;
	}

	public String getCreatName() {
		return creatName;
	}

	public void setCreatName(String creatName) {
		this.creatName = creatName;
	}
	
	public String getStName() {
		return stName;
	}

	public void setStName(String stName) {
		this.stName = stName;
	}

	public String getRoomName() {
		return roomName;
	}
	
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getMeetRyName() {
		return meetRyName;
	}
	
	public void setMeetRyName(String meetRyName) {
		this.meetRyName = meetRyName;
	}

	public String getRoomPlace() {
		return roomPlace;
	}

	public void setRoomPlace(String roomPlace) {
		this.roomPlace = roomPlace;
	}

	public Long getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(Long messageCount) {
		this.messageCount = messageCount;
	}

	public Long getReplyCount() {
		return replyCount;
	}

	public void setReplyCount(Long replyCount) {
		this.replyCount = replyCount;
	}
	
}
