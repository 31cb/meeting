package com.cb.meeting.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cb.meeting.bean.vo.UserVO;
import com.cb.meeting.dao.SysDao;
import com.cb.meeting.service.SysService;

/** 
  * @类名称 ： UserServiceImpl.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年1月23日 上午10:41:47 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年1月23日上午10:41:47----新增 
  * @---------------------------------------- 
  */

@Service
@Transactional
public class SysServiceImpl implements SysService {

	@Autowired
	private SysDao sysDao;
	
	@Override
	public UserVO findUserByName(String username) {
		UserVO userVO =  sysDao.findUserByName(username);
		userVO.setAuthId(sysDao.findAuthId(userVO.getPkid()));
		return userVO;
	}
	  
	@Override
	public void userActive(UserVO userVO) throws Exception {
		try{
			sysDao.userActive(userVO);
		}catch(Exception e){
			throw e;
		}
	}

	@Override
	public void updatePassword(UserVO userVO) throws Exception {
		try{
			sysDao.updatePassword(userVO);
		}catch(Exception e){
			throw e;
		}
	}

	  
	@Override
	public void perInfo(UserVO userVO) throws Exception {
		try{
			sysDao.perInfo(userVO);
		}catch(Exception e){
			throw e;
		}
	}

	  
	@Override
	public UserVO findUserByID(Integer pkid) throws Exception {
		UserVO userVO = sysDao.findUserByID(pkid);
		userVO.setAuthId(sysDao.findAuthId(userVO.getPkid()));
		return userVO;
	}

}
