package com.cb.meeting.service;

import java.util.List;

import com.cb.meeting.bean.vo.MeetVO;
import com.cb.meeting.bean.vo.MessageVO;
import com.cb.meeting.bean.vo.PageVO;

public interface MessageService {
	 
	/** 
	  * @方法名称 ：findList 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param user
	  * @return 
	  * @return ：List<UserEntity> 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	
	void addMessage(MessageVO messageVO) throws Exception;

	/**
	 * 
	  * @方法名称 ：findMsgByMeetId 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param meetId
	  * @return
	  * @throws Exception 
	  * @return ：List<MessageVO> 
	  * @throws ：无 
	  * @since ：Ver 1.00
	 */
	
	List<MessageVO> findMsgByMeetId(Integer meetId) throws Exception;

	
	  /** 
	  * @方法名称 ：updateMsgSt 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param meetId 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void updateMsgSt(Integer meetId) throws Exception ;

	
	  /** 
	  * @方法名称 ：findUnreadMessageCount 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pkid
	  * @return 
	  * @return ：Integer 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Integer findUnreadMessageCount(Integer userId) throws Exception ;

	
	  /** 
	  * @方法名称 ：findMeetList 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pageVO
	  * @return 
	  * @return ：List<MeetVO> 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	List<MeetVO> findMeetList(PageVO<MeetVO> pageVO) throws Exception ;

}
