
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年4月2日 
  * 创建时间: 下午1:26:17 
  */
  
package com.cb.meeting.util;

import java.util.Date;  
import java.util.Properties;  
   
import javax.mail.Message.RecipientType;  
import javax.mail.Session;  
import javax.mail.Transport;  
import javax.mail.internet.InternetAddress;  
import javax.mail.internet.MimeMessage;  



  /** 
  * @类名称 ： MailUtil.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年4月2日 下午1:26:17 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年4月2日下午1:26:17----新增 
  * @---------------------------------------- 
  */

public class MailUtil { 
	   
	    // 邮件发送协议  
	    private final static String PROTOCOL = "smtp";  
	   
	    // SMTP邮件服务器  
	    private final static String HOST = "smtp.163.com";  
	   
	    // SMTP邮件服务器默认端口  
	    private final static String PORT = "25";  
	   
	    // 是否要求身份认证  
	    private final static String IS_AUTH = "true";  
	   
	    // 是否启用调试模式（启用调试模式可打印客户端与服务器交互过程时一问一答的响应消息）  
	    private final static String IS_ENABLED_DEBUG_MOD = "true";  
	   
	    // 发件人  
	    private static String From = "m18702557813@163.com";  
	   
	    // 初始化连接邮件服务器的会话信息  
	    private static Properties props = null;  
	   
	    static {  
	        props = new Properties();  
	        props.setProperty("mail.transport.protocol", PROTOCOL);  
	        props.setProperty("mail.smtp.host", HOST);  
	        props.setProperty("mail.smtp.port", PORT);  
	        props.setProperty("mail.smtp.auth", IS_AUTH);  
	        props.setProperty("mail.debug",IS_ENABLED_DEBUG_MOD);  
	    }  
	   
	   
	    /**
	     * 发送简单的文本邮件
	     */  
	    public static boolean sendTextEmail(String to,String subject,String message) throws Exception {  
	        try {
	            // 创建Session实例对象  
	            Session session = Session.getDefaultInstance(props);  
	   
	            // 创建MimeMessage实例对象  
	            MimeMessage mimeMessage = new MimeMessage(session);  
	            // 设置发件人  
	            mimeMessage.setFrom(new InternetAddress(From));  
	            // 设置邮件主题  
	            mimeMessage.setSubject(subject);
	            // 设置收件人  
	            mimeMessage.setRecipient(RecipientType.TO, new InternetAddress(to));  
	            // 设置发送时间  
	            mimeMessage.setSentDate(new Date());  
	            // 设置纯文本内容为邮件正文  
	            mimeMessage.setText(message);  
	            // 保存并生成最终的邮件内容  
	            mimeMessage.saveChanges();  
	   
	            // 获得Transport实例对象  
	            Transport transport = session.getTransport();  
	            // 打开连接  
	            transport.connect("m18702557813", "cb18702557813");  
	            // 将message对象传递给transport对象，将邮件发送出去  
	            transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());  
	            // 关闭连接  
	            transport.close();
	             
	            return true;
	        } catch (Exception e) {
	            e.printStackTrace();
	            return false;
	        }
	    }  
}
