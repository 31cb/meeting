 package com.cb.meeting.dao;

import java.util.List;

import com.cb.meeting.bean.vo.MessageVO;

/** 
   * @类名称 ： UserDao.java 
   * @类描述 ：xxxxxx 页面 
   * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
   * @exception class：（创建由class 指定的能被抛出的异常） 
   * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年1月23日 上午10:35:30 
   * @版本 ： 1.00 * 
   * @修改记录: 
   * @版本---修改人-----修改时间----修改内容描述 
   * @---------------------------------------- 
   * @1.00---cb--2019年1月23日上午10:35:30----新增 
   * @---------------------------------------- 
   */

 public interface MessageDao {

	void addMessage(MessageVO messageVO) throws Exception;

	
	  /** 
	  * @方法名称 ：findMsgByMeetId 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param meetId
	  * @return 
	  * @return ：List<MessageVO> 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	List<MessageVO> findMsgByMeetId(Integer meetId) throws Exception;


	
	  /** 
	  * @方法名称 ：updateMsgSt 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param meetId 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void updateMsgSt(Integer meetId) throws Exception ;


	
	  /** 
	  * @方法名称 ：findUnreadMessageCount 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param userId
	  * @return 
	  * @return ：Integer 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Integer findUnreadMessageCount(Integer userId) throws Exception ;


	
	  /** 
	  * @方法名称 ：findMessageCount 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pkid
	  * @return 
	  * @return ：Long 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Long findMessageCount(Integer pkid) throws Exception ;


	
	  /** 
	  * @方法名称 ：findReplyCount 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pkid
	  * @return 
	  * @return ：Long 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Long findReplyCount(Integer pkid) throws Exception ;

 }
