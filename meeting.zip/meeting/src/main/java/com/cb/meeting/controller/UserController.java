 package com.cb.meeting.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cb.meeting.bean.vo.DataGridVO;
import com.cb.meeting.bean.vo.DeptVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.ResponseVO;
import com.cb.meeting.bean.vo.UserVO;
import com.cb.meeting.service.SysService;
import com.cb.meeting.service.UserService;


/** 
  * @类名称 ： UserController.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月22日 下午3:13:05 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月22日下午3:13:05----新增 
  * @---------------------------------------- 
  */

@Controller
@RequestMapping(value="/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private SysService sysService;

	@RequestMapping("/page")
	public String page(){
		return "userList";
	}
	
	@RequestMapping("/findUserList")
	@ResponseBody
	public DataGridVO<UserVO> findUserList(PageVO<UserVO> pageVO,UserVO userVO){
		DataGridVO<UserVO> dataGridVO = new DataGridVO<UserVO>();
		pageVO.setQueryParam(userVO);
		pageVO.setStartPage((pageVO.getPage()-1)*pageVO.getRows());
		List<UserVO> list = new ArrayList<UserVO>();
		try {
			list = userService.findUserList(pageVO);
			Integer total = userService.findCount(pageVO);
			dataGridVO.setTotal(total);
			dataGridVO.setRows(list);
		} catch (Exception e) {
			dataGridVO.setTotal(0);
			dataGridVO.setRows(list);
		}
		
		return dataGridVO;
	}

	@RequestMapping("/existUsername")
	@ResponseBody
	public ResponseVO existUsername(String username){
		ResponseVO responseVO = new ResponseVO();
		try {
			Integer exist = userService.existUsername(username);
			if(exist == 0){
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("用户名不存在");
			}else{
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("用户名已存在,请修改!");
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		}

		return responseVO;
	}
	
	@RequestMapping("/addOrUpdate")
	@ResponseBody
	public ResponseVO addOrUpdate(UserVO userVO){
		ResponseVO responseVO = new ResponseVO();
		if(userVO.getPkid() == null){
			userVO.setSt("0");
			try {
				userService.addUser(userVO);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("增加用户成功");
			} catch (Exception e) {
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("增加用户失败");
			}
		}else {
			try {
				userService.updateUser(userVO);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("修改用户成功");
			} catch (Exception e) {
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("修改用户失败");
			}
		}
		return responseVO;
	}
	
	@RequestMapping("/deleteActive")
	@ResponseBody
	public ResponseVO deleteActive(Integer pkid,HttpServletRequest request){
		ResponseVO responseVO = new ResponseVO();
		try {
			userService.deleteActive(pkid);
			UserVO curUser = new UserVO();
			curUser = sysService.findUserByID(pkid);
			HttpSession session = request.getSession();
			session.setAttribute("curUser", curUser);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("注销用户成功");
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("注销用户失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/deleteUser")
	@ResponseBody
	public ResponseVO deleteUser(Integer pkid){
		ResponseVO responseVO = new ResponseVO();
		try {
			userService.deleteUser(pkid);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("删除用户成功");
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("删除用户失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/findAllDept")
	@ResponseBody
	public ResponseVO findAllDept(){
		ResponseVO responseVO = new ResponseVO();
		List<DeptVO> list = new ArrayList<DeptVO>();
		try {
			list = userService.findAllDept();
			if(list.size() == 0){
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("还未添加部门");
				responseVO.setData(null);
			}else{
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("查询部门成功");
				responseVO.setData(list);
			};
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("查询部门失败");
		}
		return responseVO;
	}
	
}
