 package com.cb.meeting.dao;

import java.util.List;

import com.cb.meeting.bean.vo.DeptVO;
import com.cb.meeting.bean.vo.PageVO;

/** 
   * @类名称 ： UserDao.java 
   * @类描述 ：xxxxxx 页面 
   * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
   * @exception class：（创建由class 指定的能被抛出的异常） 
   * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年1月23日 上午10:35:30 
   * @版本 ： 1.00 * 
   * @修改记录: 
   * @版本---修改人-----修改时间----修改内容描述 
   * @---------------------------------------- 
   * @1.00---cb--2019年1月23日上午10:35:30----新增 
   * @---------------------------------------- 
   */

 public interface DeptDao {

	 /** 
	  * @方法名称 ：findList 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param user
	  * @return 
	  * @return ：List<UserEntity> 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	List<DeptVO> findDeptList(PageVO<DeptVO> pageVO) throws Exception ;

	
	  /** 
	  * @方法名称 ：findCount 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pageVO
	  * @return 
	  * @return ：Integer 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Integer findCount(PageVO<DeptVO> pageVO) throws Exception;


	
	  /** 
	  * @方法名称 ：addUser 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param user 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void addDept(DeptVO deptVO) throws Exception;


	
	  /** 
	  * @方法名称 ：updateUser 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param user 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void updateDept(DeptVO deptVO) throws Exception ;


	
	  /** 
	  * @方法名称 ：deleteUser 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pkid 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void deleteDept(Integer pkid) throws Exception ;


	
	  /** 
	  * @方法名称 ：existRoomNum 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param roomNum
	  * @return 
	  * @return ：Integer 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Integer existDeptNum(String deptNum) throws Exception ;


	
	  /** 
	  * @方法名称 ：existRoomName 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param roomName
	  * @return 
	  * @return ：Integer 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Integer existDeptName(String deptName) throws Exception ;

 }
