
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年2月22日 
  * 创建时间: 下午2:31:06 
  */
  
package com.cb.meeting.dao;

import java.util.List;

import com.cb.meeting.bean.entity.UserEntity;
import com.cb.meeting.bean.vo.DeptVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.UserVO;

/** 
  * @类名称 ： UserDao.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月22日 下午2:31:06 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月22日下午2:31:06----新增 
  * @---------------------------------------- 
  */

public interface UserDao {

	
	  /** 
	  * @方法名称 ：findList 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param user
	  * @return 
	  * @return ：List<UserEntity> 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	List<UserVO> findUserList(PageVO<UserVO> pageVO) throws Exception ;

	
	  /** 
	  * @方法名称 ：findCount 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pageVO
	  * @return 
	  * @return ：Integer 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Integer findCount(PageVO<UserVO> pageVO) throws Exception;


	
	  /** 
	  * @方法名称 ：addUser 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param user 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void addUser(UserVO userVO) throws Exception;


	
	  /** 
	  * @方法名称 ：existUsername 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param username
	  * @return 
	  * @return ：Integer 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	Integer existUsername(String username) throws Exception ;


	
	  /** 
	  * @方法名称 ：updateUser 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param user 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void updateUser(UserVO userVO) throws Exception ;


	
	  /** 
	  * @方法名称 ：deleteUser 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pkid 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void deleteUser(Integer pkid) throws Exception ;


	
	  /** 
	  * @方法名称 ：deleteActive 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param pkid 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	void deleteActive(Integer pkid) throws Exception ;


	
	  /** 
	  * @方法名称 ：findAllDept 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @return 
	  * @return ：List<DeptVO> 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	List<DeptVO> findAllDept() throws Exception ;


	
	  /** 
	  * @方法名称 ：findUserById 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @return 
	  * @return ：UserEntity 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	UserEntity findUserById() throws Exception ;

}
