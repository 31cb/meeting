
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年2月25日 
  * 创建时间: 上午9:42:48 
  */
  
package com.cb.meeting.bean.vo;

import java.io.Serializable;
import java.util.List;

/** 
  * @类名称 ： DataGridVO.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月25日 上午9:42:48 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月25日上午9:42:48----新增 
  * @---------------------------------------- 
  */

public class DataGridVO<T> implements Serializable{
	
	private static final long serialVersionUID = -6309683407468897714L;
	
	private List<T> rows;
	private Integer total;
	
	/** 
	* @return the total 
	*/
	
	public Integer getTotal() {
		return total;
	}
	
	/** 
	* @param total the total to set 
	*/
	
	public void setTotal(Integer total) {
		this.total = total;
	}
	
	/** 
	* @return the rows 
	*/
	
	public List<T> getRows() {
		return rows;
	}
	
	/** 
	* @param rows the rows to set 
	*/
	
	public void setRows(List<T> rows) {
		this.rows = rows;
	}
	
	
}
