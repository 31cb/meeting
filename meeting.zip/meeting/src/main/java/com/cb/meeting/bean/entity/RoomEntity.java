
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月12日 
  * 创建时间: 上午9:21:34 
  */
  
package com.cb.meeting.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** 
  * @类名称 ： RoomEntity.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月12日 上午9:21:34 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月12日上午9:21:34----新增 
  * @---------------------------------------- 
  */

@Entity
@Table(name="room")
public class RoomEntity implements Serializable {

	private static final long serialVersionUID = 1729248903252501146L;

	/**
	 * 主键ID
	 */
	@Id
	@Column(name = "pkid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer pkid;
	
	/**
	 * 会议室编号
	 */
	@Column(name = "room_num")
	private String roomNum;
		
	/**
	 * 会议室名称
	 */
	@Column(name = "room_name")
	private String roomName;
	
	/**
	 * 会议室地点
	 */
	@Column(name = "room_place")
	private String roomPlace;
	
	/**
	 * 会议室状态
	 */
	@Column(name = "room_st")
	private String roomSt;
	
	/**
	 * 会议室最大容纳人数
	 */
	@Column(name = "room_max_num")
	private Integer roomMaxNum;
	
	/**
	 * 会议室使用开始时间
	 */
	@Column(name = "room_start_time")
	private Timestamp roomStartTime;
	
	/**
	 * 会议室使用结束时间
	 */
	@Column(name = "room_end_time")
	private Timestamp roomEndTime;
	
	/**
	 * 备注
	 */
	@Column(name = "remark")
	private String remark;
	
	/** 
	* @return the pkid 
	*/
	
	public Integer getPkid() {
		return pkid;
	}
	
	/** 
	* @param pkid the pkid to set 
	*/
	
	public void setPkid(Integer pkid) {
		this.pkid = pkid;
	}
	
	/** 
	* @return the roomNum 
	*/
	
	public String getRoomNum() {
		return roomNum;
	}
	
	/** 
	* @param roomNum the roomNum to set 
	*/
	
	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
	}
	
	/** 
	* @return the roomName 
	*/
	
	public String getRoomName() {
		return roomName;
	}
	
	/** 
	* @param roomName the roomName to set 
	*/
	
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	
	/** 
	* @return the roomPlace 
	*/
	
	public String getRoomPlace() {
		return roomPlace;
	}
	
	/** 
	* @param roomPlace the roomPlace to set 
	*/
	
	public void setRoomPlace(String roomPlace) {
		this.roomPlace = roomPlace;
	}
	
	/** 
	* @return the roomSt 
	*/
	
	public String getRoomSt() {
		return roomSt;
	}
	
	/** 
	* @param roomSt the roomSt to set 
	*/
	
	public void setRoomSt(String roomSt) {
		this.roomSt = roomSt;
	}
	
	/** 
	* @return the roomMaxNum 
	*/
	
	public Integer getRoomMaxNum() {
		return roomMaxNum;
	}
	
	/** 
	* @param roomMaxNum the roomMaxNum to set 
	*/
	
	public void setRoomMaxNum(Integer roomMaxNum) {
		this.roomMaxNum = roomMaxNum;
	}
	
	/** 
	* @return the remark 
	*/
	
	public String getRemark() {
		return remark;
	}
	
	/** 
	* @param remark the remark to set 
	*/
	
	public void setRemark(String remark) {
		this.remark = remark;
	}

	
	/** 
	* @return the roomStartTime 
	*/
	
	public Timestamp getRoomStartTime() {
		return roomStartTime;
	}

	
	/** 
	* @param roomStartTime the roomStartTime to set 
	*/
	
	public void setRoomStartTime(Timestamp roomStartTime) {
		this.roomStartTime = roomStartTime;
	}
	
	/** 
	* @return the roomEndTime 
	*/
	
	public Timestamp getRoomEndTime() {
		return roomEndTime;
	}

	/** 
	* @param roomEndTime the roomEndTime to set 
	*/
	
	public void setRoomEndTime(Timestamp roomEndTime) {
		this.roomEndTime = roomEndTime;
	}
	
}
