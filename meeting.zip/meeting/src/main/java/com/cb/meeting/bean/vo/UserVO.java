
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月11日 
  * 创建时间: 下午2:32:03 
  */
  
package com.cb.meeting.bean.vo;

import java.util.List;

import com.cb.meeting.bean.entity.UserEntity;

/** 
  * @类名称 ： UserVO.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月11日 下午2:32:03 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月11日下午2:32:03----新增 
  * @---------------------------------------- 
  */

public class UserVO extends UserEntity {

	private static final long serialVersionUID = 1L;
	
	private String roleName;
	private String stName;
	private String deptName;
	private String authFlagName;
	private List<String> auth;
	private List<Integer> authId;
	
	
	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	public String getStName() {
		return stName;
	}
	
	public void setStName(String stName) {
		this.stName = stName;
	}
	
	public String getDeptName() {
		return deptName;
	}
	
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getAuthFlagName() {
		return authFlagName;
	}
	
	public void setAuthFlagName(String authFlagName) {
		this.authFlagName = authFlagName;
	}
	
	public List<String> getAuth() {
		return auth;
	}
	
	public void setAuth(List<String> auth) {
		this.auth = auth;
	}

	public List<Integer> getAuthId() {
		return authId;
	}

	public void setAuthId(List<Integer> authId) {
		this.authId = authId;
	}
	
	
}
