package com.cb.meeting.bean.vo;

import com.cb.meeting.bean.entity.MessageEntity;

public class MessageVO extends MessageEntity {

	private static final long serialVersionUID = 1003643184892026484L;

	private String userName;
	private String replyUserName;
	private String strCreatTime;
	private String typeName;
	private final String handle = "回复";

	public String getStrCreatTime() {
		return strCreatTime;
	}

	public void setStrCreatTime(String strCreatTime) {
		this.strCreatTime = strCreatTime;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getReplyUserName() {
		return replyUserName;
	}

	public void setReplyUserName(String replyUserName) {
		this.replyUserName = replyUserName;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getHandle() {
		return handle;
	}

}
