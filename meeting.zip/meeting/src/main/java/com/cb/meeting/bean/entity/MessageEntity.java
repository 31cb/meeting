package com.cb.meeting.bean.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** 
  * @类名称 ： RoomEntity.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月12日 上午9:21:34 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月12日上午9:21:34----新增 
  * @---------------------------------------- 
  */

@Entity
@Table(name="message")
public class MessageEntity implements Serializable {

	private static final long serialVersionUID = -4309771610679117703L;

	/**
	 * 主键ID
	 */
	@Id
	@Column(name = "pkid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer pkid;
	
	/**
	 * 会议ID
	 */
	@Column(name = "meet_id")
	private Integer meetId;
		
	/**
	 * 用户ID
	 */
	@Column(name = "user_id")
	private Integer userId;
	
	/**
	 * 创建时间
	 */
	@Column(name = "creat_time")
	private Timestamp creatTime;
	
	/**
	 * 内容
	 */
	@Column(name = "content")
	private String content;
	
	/**
	 * 状态
	 */
	@Column(name = "st")
	private String st;
	
	
	/**
	 * 类型
	 */
	@Column(name = "type")
	private String type;
	
	/**
	 * 回复消息ID
	 */
	@Column(name = "reply_msg_id")
	private Integer replyMsgId;
	
	/**
	 * 回复用户ID
	 */
	@Column(name = "reply_user_id")
	private Integer replyUserId;

	public Integer getPkid() {
		return pkid;
	}

	public void setPkid(Integer pkid) {
		this.pkid = pkid;
	}

	public Integer getMeetId() {
		return meetId;
	}

	public void setMeetId(Integer meetId) {
		this.meetId = meetId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Timestamp getCreatTime() {
		return creatTime;
	}

	public void setCreatTime(Timestamp creatTime) {
		this.creatTime = creatTime;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getReplyMsgId() {
		return replyMsgId;
	}

	public void setReplyMsgId(Integer replyMsgId) {
		this.replyMsgId = replyMsgId;
	}

	public Integer getReplyUserId() {
		return replyUserId;
	}

	public void setReplyUserId(Integer replyUserId) {
		this.replyUserId = replyUserId;
	}

	public String getSt() {
		return st;
	}

	public void setSt(String st) {
		this.st = st;
	}

}
