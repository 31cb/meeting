package com.cb.meeting.controller;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cb.meeting.bean.vo.DataGridVO;
import com.cb.meeting.bean.vo.MeetRoomVO;
import com.cb.meeting.bean.vo.MeetVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.ResponseVO;
import com.cb.meeting.service.AllService;
import com.cb.meeting.service.MeetService;
import com.cb.meeting.service.RoomService;


/** 
  * @类名称 ： roomController.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月22日 下午3:13:05 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月22日下午3:13:05----新增 
  * @---------------------------------------- 
  */

@Controller
@RequestMapping(value="/all")
public class AllController {
	
	@Autowired
	private AllService allService;
	
	@Autowired
	private MeetService meetService;
	
	@Autowired
	private RoomService roomService;

	@RequestMapping("/page")
	public String page(){
		return "allList";
	}
	
	@RequestMapping("/findAllList")
	@ResponseBody
	public DataGridVO<MeetVO> findAllList(PageVO<MeetVO> pageVO, MeetVO meetVO, HttpServletRequest request){
		DataGridVO<MeetVO> dataGridVO = new DataGridVO<MeetVO>();
		pageVO.setQueryParam(meetVO);
		pageVO.setStartPage((pageVO.getPage()-1)*pageVO.getRows());
		List<MeetVO> list = new ArrayList<MeetVO>();
		try {
			meetService.updateMeetStByTime(new Timestamp(System.currentTimeMillis()));
			list = allService.findAllList(pageVO);
			Integer total = allService.findCount(pageVO);
			dataGridVO.setTotal(total);
			dataGridVO.setRows(list);
		} catch (Exception e) {
			dataGridVO.setTotal(0);
			dataGridVO.setRows(list);
		}
		
		return dataGridVO;
	}
	
	@RequestMapping("/findAllRoom")
	@ResponseBody
	public ResponseVO findAllRoom(){
		ResponseVO responseVO = new ResponseVO();
		List<MeetRoomVO> list = new ArrayList<MeetRoomVO>();
		try {
			list = roomService.findAllRoom();
			if(list.size() == 0){
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("未添加会议室");
				responseVO.setData(null);
			}else{
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("查询会议室成功");
				responseVO.setData(list);
			};
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("查询会议室失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/download")
	@ResponseBody
	public ResponseVO download(MeetVO meetVO,HttpServletRequest request,HttpServletResponse response){
		ResponseVO responseVO = new ResponseVO();
		MeetVO mv = new MeetVO();
		try {
			mv = meetService.findMeetById(meetVO.getPkid());
			if((!"".equals(mv.getMeetAttachPath())) && mv.getMeetAttachPath() != null){
				String fileName = mv.getMeetAttachPath().substring(mv.getMeetAttachPath().lastIndexOf("\\")+1);
				response.setCharacterEncoding("utf-8");
			    response.setContentType("multipart/form-data");
			    response.setHeader("Content-Disposition", "attachment;filename=" + new String( fileName.getBytes("gb2312"), "ISO8859-1" ) );
				InputStream in = new FileInputStream(mv.getMeetAttachPath());
				OutputStream os = response.getOutputStream();
		        byte[] b = new byte[2048];
		        int length;
		        while ((length = in.read(b)) > 0) {
		            os.write(b, 0, length);
		        }
		        os.close();
		        in.close();
			}else{
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("该会议未上传附件");
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		} 
		return responseVO;
	}
	
}
