package com.cb.meeting.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cb.meeting.bean.vo.DataGridVO;
import com.cb.meeting.bean.vo.MeetVO;
import com.cb.meeting.bean.vo.MessageVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.ResponseVO;
import com.cb.meeting.bean.vo.UserVO;
import com.cb.meeting.service.MeetService;
import com.cb.meeting.service.MessageService;

/** 
  * @类名称 ： roomController.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月22日 下午3:13:05 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月22日下午3:13:05----新增 
  * @---------------------------------------- 
  */

@Controller
@RequestMapping(value="/message")
public class MessageController {
	
	@Autowired
	private MeetService meetService;
	
	@Autowired
	private MessageService messageService;

	@RequestMapping("/page")
	public String page(){
		return "messageList";
	}
	
	@RequestMapping("/board")
	public String board(Integer pkid,Model model){
		MeetVO meetVO =new MeetVO();
		try{
			meetVO = meetService.findMeetById(pkid);
		}catch(Exception e){
			
		}
		model.addAttribute("meet", meetVO);
		return "boardPage";
	}
	
	@RequestMapping("/findMeetList")
	@ResponseBody
	public DataGridVO<MeetVO> findMeetList(PageVO<MeetVO> pageVO, MeetVO meetVO, HttpServletRequest request){
		DataGridVO<MeetVO> dataGridVO = new DataGridVO<MeetVO>();
		UserVO curUser = (UserVO)request.getSession().getAttribute("curUser");
		meetVO.setPkid(curUser.getPkid());
		pageVO.setQueryParam(meetVO);
		pageVO.setStartPage((pageVO.getPage()-1)*pageVO.getRows());
		List<MeetVO> list = new ArrayList<MeetVO>();
		try {
			meetService.updateMeetStByTime(new Timestamp(System.currentTimeMillis()));
			list = messageService.findMeetList(pageVO);
			Integer total = meetService.findCount(pageVO);
			dataGridVO.setTotal(total);
			dataGridVO.setRows(list);
		} catch (Exception e) {
			dataGridVO.setTotal(0);
			dataGridVO.setRows(list);
		}
		
		return dataGridVO;
	}
	
	@ResponseBody
	@RequestMapping("/sendMsg")
	public ResponseVO sendMsg(MessageVO messageVO,HttpServletRequest request){
		ResponseVO  responseVO = new ResponseVO();
		UserVO curUser = (UserVO) request.getSession().getAttribute("curUser");
		messageVO.setUserId(curUser.getPkid());
		messageVO.setCreatTime(new Timestamp(System.currentTimeMillis()));
		if(messageVO.getType() == null || messageVO.getType() == ""){
			messageVO.setType("1");
		}
		if(messageVO.getReplyMsgId() == null || messageVO.getReplyUserId() == null){
			messageVO.setReplyMsgId(0);
			messageVO.setReplyUserId(0);
		}
		try{
			messageService.addMessage(messageVO);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("添加消息成功");
		}catch(Exception e){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("发送失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/findMsgByMeetId")
	@ResponseBody
	public DataGridVO<MessageVO> findMsgByMeetId(Integer meetId, HttpServletRequest request){
		DataGridVO<MessageVO> dataGridVO = new DataGridVO<MessageVO>();
		List<MessageVO> list = new ArrayList<MessageVO>();
		try {
			messageService.updateMsgSt(meetId);
			list = messageService.findMsgByMeetId(meetId);
			dataGridVO.setRows(list);
		} catch (Exception e) {
			dataGridVO.setRows(list);
		}
		return dataGridVO;
	}
	
	@RequestMapping("/findUnreadMessageCount")
	@ResponseBody
	public ResponseVO findUnreadMessageCount(HttpServletRequest request){
		ResponseVO responseVO = new ResponseVO();
		HttpSession session = request.getSession();
		UserVO curUser = (UserVO) session.getAttribute("curUser");
		Integer count = 0;
		try {
			count = messageService.findUnreadMessageCount(curUser.getPkid());
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("查询未读消息成功");
			responseVO.setData(count);
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("查询未读消息失败");
			responseVO.setData(count);
		}
		return responseVO;
	}
	
}
