
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月22日 
  * 创建时间: 下午4:45:50 
  */
  
package com.cb.meeting.bean.vo;

import java.io.Serializable;

/** 
  * @类名称 ： MeetUserVO.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月22日 下午4:45:50 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月22日下午4:45:50----新增 
  * @---------------------------------------- 
  */

public class MeetUserVO implements Serializable {

	private static final long serialVersionUID = -7129291619567880141L;
	
	private Integer meetUserId;
	private String meetUserName;
	
	public Integer getMeetUserId() {
		return meetUserId;
	}

	public void setMeetUserId(Integer meetUserId) {
		this.meetUserId = meetUserId;
	}

	public String getMeetUserName() {
		return meetUserName;
	}
	
	public void setMeetUserName(String meetUserName) {
		this.meetUserName = meetUserName;
	}	
	
}
