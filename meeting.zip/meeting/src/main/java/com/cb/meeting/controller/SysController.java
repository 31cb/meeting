package com.cb.meeting.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cb.meeting.bean.vo.ResponseVO;
import com.cb.meeting.bean.vo.UserVO;
import com.cb.meeting.service.SysService;

@Controller
@RequestMapping("/sys")
public class SysController {
	
	@Autowired
	private SysService sysService;

	@ResponseBody
	@RequestMapping("/login")
	public ResponseVO login(UserVO userVO,HttpServletRequest request){
		
		ResponseVO responseVO = new ResponseVO();
		UserVO user = sysService.findUserByName(userVO.getUsername());
		if(user == null){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("用户不存在");
		}else if(!userVO.getPassword().equals(user.getPassword())){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("密码错误");
		}else if("0".equals(user.getSt()) || user.getSt()==null){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("未激活，请前往激活！");
		}else{
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("登录成功");
			responseVO.setData(user);
			HttpSession session = request.getSession();
			session.setAttribute("curUser", user);
		}
		
		return responseVO;
	}
	
	@RequestMapping("/toMain")
	public String toMain(String pkid){
		return "main";
	}
	@RequestMapping("/toActive")
	public String toActive(){
		return "userActive";
	}
	@RequestMapping("/toIndex")
	public String toIndex(){
		return "index";
	}
	
	@ResponseBody
	@RequestMapping("/userActive")
	public ResponseVO userActive(UserVO userVO){
		ResponseVO responseVO = new ResponseVO();
		UserVO user = sysService.findUserByName(userVO.getUsername());
		if(user == null){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("用户不存在");
		}else if(!userVO.getPassword().equals(user.getPassword())){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("密码错误");
		}else if("1".equals(user.getSt())){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("该用户已激活，激活失败！");
		}else{
			user.setName(userVO.getName());
			user.setPhoneNum(userVO.getPhoneNum());
			user.setEmail(userVO.getEmail());
			user.setSt("1");   //0:未激活 1:激活
			try{
				sysService.userActive(user);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("激活成功");
				responseVO.setData(user);
			}catch(Exception e){
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("激活失败");
				responseVO.setData(user);
			}
		}
		
		return responseVO;
	}
	
	@ResponseBody
	@RequestMapping("/updatePassword")
	public ResponseVO updatePassword(UserVO userVO){
		ResponseVO responseVO = new ResponseVO();
		try{
			sysService.updatePassword(userVO);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("修改成功");
		}catch(Exception e){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("修改失败");
		}
		
		return responseVO;
	}

	@ResponseBody
	@RequestMapping("/perInfo")
	public ResponseVO perInfo(UserVO userVO, HttpServletRequest request){
		ResponseVO responseVO = new ResponseVO();
		try{
			sysService.perInfo(userVO);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("保存成功");
		}catch(Exception e){
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("保存失败");
		}
		UserVO newUser = new UserVO();
		HttpSession session = request.getSession();
		session.setAttribute("curUser", newUser);
		try {
			newUser = sysService.findUserByID(userVO.getPkid());
			session.setAttribute("curUser", newUser);
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("获取个人信息出错");
		}
		
		return responseVO;
	}

	@ResponseBody
	@RequestMapping("/getCurUser")
	public ResponseVO getCurUser(HttpServletRequest request){
		ResponseVO responseVO = new ResponseVO();
		UserVO curUser = (UserVO) request.getSession().getAttribute("curUser");
		if(curUser != null){
			responseVO.setData(curUser);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("获取当前登录用户成功");
		}else{
			responseVO.setData(null);
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("获取当前登录用户失败");
		}
		return responseVO;
	}
	
}
