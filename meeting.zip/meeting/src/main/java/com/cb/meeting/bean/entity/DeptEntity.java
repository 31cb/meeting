
  /** 
  * 项目名称：自主研发平台 
  * 创建日期：2019年3月12日 
  * 创建时间: 上午9:21:34 
  */
  
package com.cb.meeting.bean.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** 
  * @类名称 ： RoomEntity.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年3月12日 上午9:21:34 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年3月12日上午9:21:34----新增 
  * @---------------------------------------- 
  */

@Entity
@Table(name="dept")
public class DeptEntity implements Serializable {

	private static final long serialVersionUID = 6496363846741218814L;

	/**
	 * 主键ID
	 */
	@Id
	@Column(name = "pkid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer pkid;
	
	/**
	 * 会议室编号
	 */
	@Column(name = "dept_num")
	private String deptNum;
		
	/**
	 * 会议室名称
	 */
	@Column(name = "dept_name")
	private String deptName;
	
	/**
	 * 备注
	 */
	@Column(name = "remark")
	private String remark;
	
	/** 
	* @return the pkid 
	*/
	
	public Integer getPkid() {
		return pkid;
	}
	
	/** 
	* @param pkid the pkid to set 
	*/
	
	public void setPkid(Integer pkid) {
		this.pkid = pkid;
	}
	
	
	/** 
	* @return the deptNum 
	*/
	
	public String getDeptNum() {
		return deptNum;
	}

	
	/** 
	* @param deptNum the deptNum to set 
	*/
	
	public void setDeptNum(String deptNum) {
		this.deptNum = deptNum;
	}

	
	/** 
	* @return the deptName 
	*/
	
	public String getDeptName() {
		return deptName;
	}

	
	/** 
	* @param deptName the deptName to set 
	*/
	
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/** 
	* @return the remark 
	*/
	
	public String getRemark() {
		return remark;
	}
	
	/** 
	* @param remark the remark to set 
	*/
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
}
