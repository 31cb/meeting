package com.cb.meeting.service;

import com.cb.meeting.bean.vo.UserVO;

/** 
  * @类名称 ： UserService.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年1月23日 上午10:40:34 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年1月23日上午10:40:34----新增 
  * @---------------------------------------- 
  */

public interface SysService {

	public UserVO findUserByName(String username) ;

	
	  /** 
	  * @方法名称 ：userActive 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param user 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	public void userActive(UserVO userVO) throws Exception ;


	
	  /** 
	  * @方法名称 ：updatePassword 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param password 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	public void updatePassword(UserVO userVO) throws Exception ;


	
	  /** 
	  * @方法名称 ：perInfo 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param userEntity 
	  * @return ：void 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	public void perInfo(UserVO userVO) throws Exception ;


	
	  /** 
	  * @方法名称 ：findUserByID 
	  * @功能描述 ： 
	  * @see class #method： (指明相关的方法名，如查询某一个客户的资料信息，可能根据客户号查询或客户名称查询，则这两个方 法名可认为是相关的，可在此罗列出） 
	  * @逻辑描述 ： 
	  * @param userEntity
	  * @return 
	  * @return ：UserEntity 
	  * @throws ：无 
	  * @since ：Ver 1.00 
	  */
	  
	public UserVO findUserByID(Integer pkid) throws Exception ;

}
