package com.cb.meeting.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.cb.meeting.bean.vo.DataGridVO;
import com.cb.meeting.bean.vo.MeetRoomVO;
import com.cb.meeting.bean.vo.MeetVO;
import com.cb.meeting.bean.vo.PageVO;
import com.cb.meeting.bean.vo.ResponseVO;
import com.cb.meeting.bean.vo.RoomVO;
import com.cb.meeting.bean.vo.UserVO;
import com.cb.meeting.service.MeetService;
import com.cb.meeting.service.RoomService;
import com.cb.meeting.util.MailUtil;


/** 
  * @类名称 ： roomController.java 
  * @类描述 ：xxxxxx 页面 
  * @see class ： （列出与此程序相关的类，如从哪个类继承及功能类似的类等） 
  * @exception class：（创建由class 指定的能被抛出的异常） 
  * @作者 : chenbo@tansun.com.cn * @创建时间 ： 2019年2月22日 下午3:13:05 
  * @版本 ： 1.00 * 
  * @修改记录: 
  * @版本---修改人-----修改时间----修改内容描述 
  * @---------------------------------------- 
  * @1.00---cb--2019年2月22日下午3:13:05----新增 
  * @---------------------------------------- 
  */

@Controller
@RequestMapping(value="/meet")
public class MeetController {
	
	@Autowired
	private MeetService meetService;
	
	@Autowired
	private RoomService roomService;

	@RequestMapping("/page")
	public String page(){
		return "meetList";
	}
	
	@RequestMapping("/findPendMeetCount")
	@ResponseBody
	public ResponseVO findPendMeetCount(HttpServletRequest request){
		ResponseVO responseVO = new ResponseVO();
		HttpSession session = request.getSession();
		UserVO curUser = (UserVO) session.getAttribute("curUser");
		Integer count = 0;
		try {
			count = meetService.findPendMeetCount(curUser.getPkid());
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("查询待参加会议成功");
			responseVO.setData(count);
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("查询待参加会议失败");
			responseVO.setData(count);
		}
		return responseVO;
	}
	
	@RequestMapping("/findMeetList")
	@ResponseBody
	public DataGridVO<MeetVO> findMeetList(PageVO<MeetVO> pageVO, MeetVO meetVO, HttpServletRequest request){
		DataGridVO<MeetVO> dataGridVO = new DataGridVO<MeetVO>();
		UserVO curUser = (UserVO)request.getSession().getAttribute("curUser");
		meetVO.setPkid(curUser.getPkid());
		pageVO.setQueryParam(meetVO);
		pageVO.setStartPage((pageVO.getPage()-1)*pageVO.getRows());
		List<MeetVO> list = new ArrayList<MeetVO>();
		try {
			meetService.updateMeetStByTime(new Timestamp(System.currentTimeMillis()));
			list = meetService.findMeetList(pageVO);
			Integer total = meetService.findCount(pageVO);
			dataGridVO.setTotal(total);
			dataGridVO.setRows(list);
		} catch (Exception e) {
			dataGridVO.setTotal(0);
			dataGridVO.setRows(list);
		}
		
		return dataGridVO;
	}
	
	@RequestMapping("/addOrUpdate")
	@ResponseBody
	public ResponseVO addOrUpdate(MeetVO meetVO,MultipartFile file,HttpServletRequest request){
		ResponseVO responseVO = new ResponseVO();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		if(meetVO.getPkid() == null){
			try {
				if(!file.isEmpty()) {
		            //上传文件路径
					String path = request.getSession().getServletContext().getRealPath("/WEB-INF/upload/" + df.format(new Date()));
		            //上传文件名
		            String filename = file.getOriginalFilename();
		            File filepath = new File(path,filename);
		            //判断路径是否存在，如果不存在就创建一个
		            if (!filepath.getParentFile().exists()) { 
		                filepath.getParentFile().mkdirs();
		            }
		            //将上传文件保存到一个目标文件当中
		            file.transferTo(new File(path + File.separator + filename));
		            meetVO.setMeetAttachPath(filepath.toString());
				}
				UserVO curUser = (UserVO)request.getSession().getAttribute("curUser");
				
				meetVO.setCreatTime(new Timestamp(System.currentTimeMillis()));
				meetVO.setCreatUser(curUser.getPkid());
				meetVO.setLastUpdateTime(new Timestamp(System.currentTimeMillis()));
				meetVO.setMeetSt("0");
				if("".equals(meetVO.getMeetRy()) || meetVO.getMeetRy() == null)
					meetVO.setMeetRy(meetVO.getCreatUser().toString());
				meetService.addMeet(meetVO);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("添加会议成功");
			} catch (Exception e) {
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("添加会议失败");
			}
		}else {
			try {
				if(!file.isEmpty()) {
		            //上传文件路径
					String path = request.getSession().getServletContext().getRealPath("/WEB-INF/upload/" + df.format(new Date()));
		            //上传文件名 
		            String filename = file.getOriginalFilename();
		            File filepath = new File(path,filename);
		            //判断路径是否存在，如果不存在就创建一个
		            if (!filepath.getParentFile().exists()) { 
		                filepath.getParentFile().mkdirs();
		            }
		            //将上传文件保存到一个目标文件当中
		            file.transferTo(new File(path + File.separator + filename));
		            meetVO.setMeetAttachPath(filepath.toString());
				}
				meetVO.setLastUpdateTime(new Timestamp(System.currentTimeMillis()));
				meetService.updateMeet(meetVO);
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("修改会议成功");
				MeetVO meet = meetService.findMeetById(meetVO.getPkid());
				if("1".equals(meet.getSendFlag())){
					updateSend(meetVO.getPkid());
				}
			} catch (Exception e) {
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("修改会议失败");
			}
		}
		return responseVO;
	}
	
	@RequestMapping("/deleteMeet")
	@ResponseBody
	public ResponseVO deleteMeet(Integer pkid){
		ResponseVO responseVO = new ResponseVO();
		try {
			MeetVO meetVO = meetService.findMeetById(pkid);
			if("1".equals(meetVO.getSendFlag())){
				List<UserVO> userVO = meetService.findUserListByMeetId(pkid);
				for (UserVO user : userVO) {
					try{
						String message = "你好，"+user.getName()+"！"+"主题为：《"+meetVO.getMeetTheme()+"》，会议时间为：“"+meetVO.getStrStTime()+"”的会议已取消！";
						MailUtil.sendTextEmail(user.getEmail(), "会议取消通知", message);
					}catch (Exception e){
						responseVO.setStatus(ResponseVO.ERROR);
						responseVO.setDescription("发送会议通知出错，邮箱:"+user.getEmail());
						return responseVO;
					}
				}
			}
			meetService.deleteMeet(pkid);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("取消会议成功");
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("取消会议失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/findAllRoom")
	@ResponseBody
	public ResponseVO findAllRoom(){
		ResponseVO responseVO = new ResponseVO();
		List<MeetRoomVO> list = new ArrayList<MeetRoomVO>();
		try {
			list = roomService.findAllRoom();
			if(list.size() == 0){
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("未添加会议室");
				responseVO.setData(null);
			}else{
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("查询会议室成功");
				responseVO.setData(list);
			};
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("查询会议室失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/roomAvailable")
	@ResponseBody
	public ResponseVO roomAvailable(MeetRoomVO meetRoomVO){
		ResponseVO responseVO = new ResponseVO();
		try {
			boolean available = roomService.roomAvailable(meetRoomVO);
			RoomVO roomVO = roomService.findRoomById(meetRoomVO.getMeetRoomId());
			if(available){
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("该时间段会议室未被使用");
				responseVO.setData(roomVO);
			}else{
				responseVO.setStatus(ResponseVO.OK);
				responseVO.setDescription("该时间段该会议室已被使用");
				responseVO.setData(roomVO);
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/download")
	@ResponseBody
	public ResponseVO download(MeetVO meetVO,HttpServletRequest request,HttpServletResponse response){
		ResponseVO responseVO = new ResponseVO();
		MeetVO mv = new MeetVO();
		try {
			mv = meetService.findMeetById(meetVO.getPkid());
			if((!"".equals(mv.getMeetAttachPath())) && mv.getMeetAttachPath() != null){
				String fileName = mv.getMeetAttachPath().substring(mv.getMeetAttachPath().lastIndexOf("\\")+1);
				response.setCharacterEncoding("utf-8");
			    response.setContentType("multipart/form-data");
			    response.setHeader("Content-Disposition", "attachment;filename=" + new String( fileName.getBytes("gb2312"), "ISO8859-1" ) );
				InputStream in = new FileInputStream(mv.getMeetAttachPath());
				OutputStream os = response.getOutputStream();
		        byte[] b = new byte[2048];
		        int length;
		        while ((length = in.read(b)) > 0) {
		            os.write(b, 0, length);
		        }
		        os.close();
		        in.close();
			}else{
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("该会议未上传附件");
			}
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		} 
		return responseVO;
	}
	
	@RequestMapping("/endMeet")
	@ResponseBody
	public ResponseVO endMeet(MeetVO meetVO,MultipartFile file,HttpServletRequest request){
		ResponseVO responseVO = new ResponseVO();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try {
			if(!file.isEmpty()) {
	            //上传文件路径
				String path = request.getSession().getServletContext().getRealPath("/WEB-INF/upload/" + df.format(new Date()));
	            //上传文件名
	            String filename = file.getOriginalFilename();
	            File filepath = new File(path,filename);
	            //判断路径是否存在，如果不存在就创建一个
	            if (!filepath.getParentFile().exists()) { 
	                filepath.getParentFile().mkdirs();
	            }
	            //将上传文件保存到一个目标文件当中
	            file.transferTo(new File(path + File.separator + filename));
	            meetVO.setMeetAttachPath(filepath.toString());
			}
			meetVO.setMeetSt("1");
			meetService.updateMeetEnd(meetVO);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("会议完成");
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription("操作失败");
		}
		return responseVO;
	}
	
	@RequestMapping("/send")
	@ResponseBody
	public ResponseVO send(Integer pkid){
		ResponseVO responseVO = new ResponseVO();
		List<UserVO> userVO = new ArrayList<UserVO>();
		UserVO creatUser = new UserVO();
		MeetVO meetVO = new MeetVO();
		try{
			userVO = meetService.findUserListByMeetId(pkid);
			creatUser = meetService.findCreatUser(pkid);
			meetVO = meetService.findMeetById(pkid);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("查询成功");
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription(e.getMessage());
			return responseVO;
		}
		for (UserVO user : userVO) {
			try{
				if(user.getPkid() == creatUser.getPkid()){
					String message = "你好，"+user.getName()+"！你发起了主题为：《"+meetVO.getMeetTheme()+"》的会议，会议时间为：“"+meetVO.getStrStTime()+"”，请准时在 "+meetVO.getRoomName()+"("+meetVO.getRoomPlace()+") 主持会议！";
					MailUtil.sendTextEmail(user.getEmail(), "会议通知", message);
				}else {
					String message = "你好，"+user.getName()+"！"+creatUser.getName()+"发起了主题为：《"+meetVO.getMeetTheme()+"》的会议，会议时间为：“"+meetVO.getStrStTime()+"”，请准时在 "+meetVO.getRoomName()+"("+meetVO.getRoomPlace()+") 参加会议！";
					MailUtil.sendTextEmail(user.getEmail(), "会议通知", message);
				}
			}catch (Exception e){
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("发送会议通知出错，邮箱:"+user.getEmail());
				return responseVO;
			}
		}
		try {
			meetService.updateMeetSendFlag(pkid);
		} catch (Exception e) {
			
		}
		responseVO.setStatus(ResponseVO.OK);
		responseVO.setDescription("发送成功");
		return responseVO;
	}
	
	public ResponseVO updateSend(Integer pkid){
		ResponseVO responseVO = new ResponseVO();
		List<UserVO> userVO = new ArrayList<UserVO>();
		UserVO creatUser = new UserVO();
		MeetVO meetVO = new MeetVO();
		try{
			userVO = meetService.findUserListByMeetId(pkid);
			creatUser = meetService.findCreatUser(pkid);
			meetVO = meetService.findMeetById(pkid);
			responseVO.setStatus(ResponseVO.OK);
			responseVO.setDescription("查询成功");
		} catch (Exception e) {
			responseVO.setStatus(ResponseVO.ERROR);
			responseVO.setDescription(e.getMessage());
			return responseVO;
		}
		for (UserVO user : userVO) {
			try{
				if(user.getPkid() == creatUser.getPkid()){
					String message = "你好，"+user.getName()+"！你修改了主题为：《"+meetVO.getMeetTheme()+"》的会议，会议时间为：“"+meetVO.getStrStTime()+"”，请准时在 "+meetVO.getRoomName()+"("+meetVO.getRoomPlace()+") 主持会议！";
					MailUtil.sendTextEmail(user.getEmail(), "会议修改通知", message);
				}else {
					String message = "你好，"+user.getName()+"！"+creatUser.getName()+"修改了主题为：《"+meetVO.getMeetTheme()+"》的会议，会议时间为：“"+meetVO.getStrStTime()+"”，请准时在 "+meetVO.getRoomName()+"("+meetVO.getRoomPlace()+") 参加会议！";
					MailUtil.sendTextEmail(user.getEmail(), "会议修改通知", message);
				}
			}catch (Exception e){
				responseVO.setStatus(ResponseVO.ERROR);
				responseVO.setDescription("发送会议通知出错，邮箱:"+user.getEmail());
				return responseVO;
			}
		}
		try {
			meetService.updateMeetSendFlag(pkid);
		} catch (Exception e) {
			
		}
		responseVO.setStatus(ResponseVO.OK);
		responseVO.setDescription("发送成功");
		return responseVO;
	}
	
}
